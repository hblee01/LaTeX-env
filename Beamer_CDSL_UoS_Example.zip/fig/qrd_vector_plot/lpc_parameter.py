# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import os, datetime, pathlib, shutil # to save figures
import sys

class LpcParameter:
    def __init__(self, dir_name=None, 
                 task_method=None, task_parameter=[], 
                 control_method=None, control_parameter=[]):
        plt.close('all')
        #%%
        self.save_data = 1  # 0(no) / 1(ok)
        
        self.make_figure = 1
        self.save_figure = 1
        self.figure_format = 'pdf'
        self.figure_size = (9,9) # [inches]
        
        self.make_movie = 1
        self.save_movie = 0
        self.movie_fps = 20
        self.movie_speed = 0.5
        
        self.task_method = task_method
        self.task_parameter = task_parameter
        self.control_method = control_method
        self.control_parameter = control_parameter
        
        self.l1=0.6; self.l2=0.4
        self.q1=-40*np.pi/180; self.q2=80*np.pi/180
        self.dq1=0; self.dq2=0
        
        self.ti = 0; self.tf = 5; self.dt = 0.001
        self.ti_task = 0; self.tp_task = 5
        
        self.clik = [10.0, 10.0]
            
        if (self.control_method != None) & (self.control_parameter == []):
            if self.control_method == 0: # damped pseudoinverse solution
                # [lambda0]
                self.control_parameter = [0.145]
            elif self.control_method == 1: # transpose solution
                self.control_parameter = []
                self.clik = [165.0, 165.0]
            elif self.control_method == 2: # pi1-PIK solution with constant dampings
                # [lambda1, lambda2]
                self.control_parameter = [0.41, 0.41]  # chattering
                #self.control_parameter = [0.54, 0.54]  # no chattering
            elif self.control_method == 3: # pi1-PIK solution with imperfect projections
                # [epsilon, lambda1, lambda2]
                self.control_parameter = [0.001, 0.157, 0.157]
            elif self.control_method == 4: # pi1-PIK solution with varying dampings
                # [mu1, mu2, nu]
                self.control_parameter = [0.001, 0.001, 1]
            elif self.control_method == 5: # pi1-PIK solution with varying dampings with varying mu
                # [mu_min1, mu_min2, mu_max1, mu_max2, rate, nu]
                self.control_parameter = [0.001, 0.001, 0.01, 0.01, 10, 1]
            else:
                print(f'Invalid control method: control_method = {self.control_method}')
                sys.exit()
        #%%
        if dir_name == None:
            self.save_path = None
        else:
            date_time = datetime.datetime.now().strftime(f"%Y%m%d_%H%M%S_{dir_name}")
            parent_dir = pathlib.Path(os.getcwd()).parent
            self.save_path = os.path.join(parent_dir, "data", date_time)
            if os.path.exists(self.save_path) == True:
                print(f"save_path exists: save_path = {self.save_path}")
                sys.exit()
            else:
                pathlib.Path(self.save_path).mkdir(parents=True, exist_ok=True)
                src_path = os.getcwd()
                src_files = os.listdir(src_path)
                for file_name in src_files:
                    full_file_name = os.path.join(src_path, file_name)
                    if os.path.isfile(full_file_name) & (full_file_name[-3:] == '.py'):
                        shutil.copy(full_file_name, self.save_path)