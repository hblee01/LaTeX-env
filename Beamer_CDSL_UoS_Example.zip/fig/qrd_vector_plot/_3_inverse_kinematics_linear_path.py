# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rc('text', usetex=True)

import os

from lpc_simulation import LpcSimulation

class InverseKinematicsLinearPath():
    def __init__(self, prm):
        print("""
InverseKinematicsLinearPath starts:
        """)
        #%% Figure Parameters
        title_fontsize = 25
        #label_fontsize = 25
        tick_fontsize = 20
        legend_fontsize = 18
        
        figsize = [prm.figure_size[0], prm.figure_size[1]]
        fig_num = -1
        
        prm.task_method = 0 # linear path
        
        #%% Dmped Pseudoinvese Solution
        
        lambda0 = [0.05, 0.04, 0.04, 0.04]
        #dt = [0.01, 0.01, 0.007, 0.001]
        dt = [0.01, 0.01, 0.001, 0.0001]
        prm.control_method = 0 # damped pseudoinverse solution
        
        fig, axs = plt.subplots(
            len(dt),3,
            figsize=figsize,
            sharex='col',
            gridspec_kw={'width_ratios': [0.5,1.5,1.5]}
            )
        
        for i in range(len(dt)):
            prm.control_parameter = [lambda0[i]]
            prm.dt = dt[i]
            sim = LpcSimulation(prm, plot=False)
            ###
            axs[i,0].set_xlim(-1,1)
            axs[i,0].set_ylim(-1,1)
            axs[i,0].set_xticks([])
            axs[i,0].set_yticks([])
            axs[i,0].set_frame_on(False)
            axs[i,0].text(
                0,0,
                r'$\lambda = %g$'%lambda0[i]+'\n'+r'$\delta = %g$'%dt[i],
                ha='center', va='center',
                fontsize=title_fontsize)
            ###
            # axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
            #               label=r'$\mathbf{p}(t)$')
            # axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
            #               label=r'$\mathbf{f}(\mathbf{q}(t))$')
            axs[i,1].plot(sim.plot.time, sim.plot.error[:,0], 'k--', 
                          label=r'$\mathbf{p}(t)$')
            axs[i,1].plot(sim.plot.time, sim.plot.error[:,1], 'k',
                          label=r'$\mathbf{f}(\mathbf{q}(t))$')
            axs[i,1].grid()
            #axs[i,1].set_aspect('equal')
            # axs[i,1].set_xlim(0.7,1.3)
            # axs[i,1].set_ylim(-0.3,0.3)
            # axs[i,1].set_xticks([0.7,1,1.3])
            # axs[i,1].set_yticks([-0.3,0,0.3])
            #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
            #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
            # if i == 0:
            #     axs[i,1].legend(fontsize=legend_fontsize, 
            #                     framealpha=0.0,
            #                     loc='center',
            #                     bbox_to_anchor=(0.55,0.5))
            # for j in range(len(sim.plot.time)):
            #     if sim.plot.time[j] % 0.1 < sim.dt:
            #         axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
            #                       [sim.plot.p[j,1], sim.plot.f2[j,1]],
            #                       'k:')
                    # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
                    #               marker='o', markersize=1.5)
            ###
            axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
                          label=r'$\dot{q}_1(t)$')
            axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
                          label=r'$\dot{q}_2(t)$')
            axs[i,2].grid()
            # axs[i,2].set_xlim(prm.ti,prm.tf)
            # axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
            # if i == 0:
            #     axs[i,2].set_yticks([-6,-3,0,3,6])
            # elif i == 1:
            #     axs[i,2].set_yticks([-30,-15,0,15,30])
            # elif i == 2:
            #     axs[i,2].set_yticks([-6,-3,0,3,6])
            # elif i == 3:
            #     axs[i,2].set_yticks([-6,-3,0,3,6])
            #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
            #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
            if i == 0:
                axs[i,2].legend(fontsize=legend_fontsize, 
                                framealpha=0.0,
                                loc='upper left',
                                bbox_to_anchor=(-0.03,1.05))
            
            for j in range(2):
                for tick in axs[i,j+1].xaxis.get_major_ticks():
                    tick.label.set_fontsize(tick_fontsize)
                for tick in axs[i,j+1].yaxis.get_major_ticks():
                    tick.label.set_fontsize(tick_fontsize)
    
        #fig.align_ylabels(axs[:,0])
        #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
        fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        
        fig_num += 1
        if (prm.save_path != None) & (prm.save_figure == 1):
            file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_damped_pseudoinverse_solution.{prm.figure_format}')
            plt.savefig(file_name, format=prm.figure_format)
            
        #%% pi1-PIK Solution with Constant Damping
        
        # lambda0 = [0.6, 0.5, 0.5, 0.5]
        # dt = [0.01, 0.01, 0.001, 0.0001]
        # # lambda0 = [0.6, 0.1, 0.1, 0.1]
        # # dt = [0.01, 0.01, 0.001, 0.0001]
        # prm.control_method = 2 # pi1-PIK solution with constant damping
        
        # fig, axs = plt.subplots(
        #     len(dt),3,
        #     figsize=figsize,
        #     sharex='col',
        #     gridspec_kw={'width_ratios': [0.5,1,2]}
        #     )
        
        # for i in range(len(dt)):
        #     prm.control_parameter = [lambda0[i], lambda0[i]]
        #     prm.dt = dt[i]
        #     sim = LpcSimulation(prm, plot=False)
        #     ###
        #     axs[i,0].set_xlim(-1,1)
        #     axs[i,0].set_ylim(-1,1)
        #     axs[i,0].set_xticks([])
        #     axs[i,0].set_yticks([])
        #     axs[i,0].set_frame_on(False)
        #     axs[i,0].text(
        #         0,0,
        #         r'$\lambda = %g$'%lambda0[i]+'\n'+r'$\delta = %g$'%dt[i],
        #         ha='center', va='center',
        #         fontsize=title_fontsize)
        #     ###
        #     axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
        #                   label=r'$\mathbf{p}(t)$')
        #     axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
        #                   label=r'$\mathbf{f}(\mathbf{q}(t))$')
        #     axs[i,1].grid()
        #     axs[i,1].set_aspect('equal')
        #     axs[i,1].set_xlim(0.7,1.3)
        #     axs[i,1].set_ylim(-0.3,0.3)
        #     axs[i,1].set_xticks([0.7,1,1.3])
        #     axs[i,1].set_yticks([-0.3,0,0.3])
        #     #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
        #     #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
        #     # if i == 0:
        #     #     axs[i,1].legend(fontsize=legend_fontsize, 
        #     #                     framealpha=0.0,
        #     #                     loc='center',
        #     #                     bbox_to_anchor=(0.55,0.5))
        #     for j in range(len(sim.plot.time)):
        #         if sim.plot.time[j] % 0.1 < sim.dt:
        #             axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
        #                           [sim.plot.p[j,1], sim.plot.f2[j,1]],
        #                           'k:')
        #             # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
        #             #               marker='o', markersize=1.5)
        #     ###
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
        #                   label=r'$\dot{q}_1(t)$')
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
        #                   label=r'$\dot{q}_2(t)$')
        #     axs[i,2].grid()
        #     axs[i,2].set_xlim(prm.ti,prm.tf)
        #     axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
        #     axs[i,2].set_yticks([-2,0,2,4])
        #     #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
        #     #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
        #     if i == 0:
        #         axs[i,2].legend(fontsize=legend_fontsize, 
        #                         framealpha=0.0,
        #                         loc='upper left',
        #                         bbox_to_anchor=(-0.03,1.05))
            
        #     for j in range(2):
        #         for tick in axs[i,j+1].xaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
        #         for tick in axs[i,j+1].yaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
    
        # #fig.align_ylabels(axs[:,0])
        # #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
        # fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        
        # fig_num += 1
        # if (prm.save_path != None) & (prm.save_figure == 1):
        #     file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_constant_dampings.{prm.figure_format}')
        #     plt.savefig(file_name, format=prm.figure_format)
        
        #%% pi1-PIK Solution with Varying Dampings
        
        # nu = 1
        # mu = [0.02, 0.01, 0.01, 0.01]
        # dt = [0.01, 0.01, 0.001, 0.0001]
        # # dt = [0.01, 0.01, 0.005, 0.001]
        # prm.control_method = 4 # pi1-PIK solution with varying dampings
        
        # fig, axs = plt.subplots(
        #     len(dt),3,
        #     figsize=figsize,
        #     sharex='col',
        #     gridspec_kw={'width_ratios': [0.5,1,2]}
        #     )
        
        # for i in range(len(dt)):
        #     prm.control_parameter = [mu[i], mu[i], nu]
        #     prm.dt = dt[i]
        #     sim = LpcSimulation(prm, plot=False)
        #     ###
        #     axs[i,0].set_xlim(-1,1)
        #     axs[i,0].set_ylim(-1,1)
        #     axs[i,0].set_xticks([])
        #     axs[i,0].set_yticks([])
        #     axs[i,0].set_frame_on(False)
        #     axs[i,0].text(
        #         0,0,
        #         r'$\nu=%g$'%nu+'\n'+r'$\mu = %g$'%mu[i]+'\n'+r'$\delta = %g$'%dt[i],
        #         ha='center', va='center',
        #         fontsize=title_fontsize)
        #     ###
        #     axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
        #                   label=r'$\mathbf{p}(t)$')
        #     axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
        #                   label=r'$\mathbf{f}(\mathbf{q}(t))$')
        #     axs[i,1].grid()
        #     axs[i,1].set_aspect('equal')
        #     axs[i,1].set_xlim(0.7,1.3)
        #     axs[i,1].set_ylim(-0.3,0.3)
        #     axs[i,1].set_xticks([0.7,1,1.3])
        #     axs[i,1].set_yticks([-0.3,0,0.3])
        #     #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
        #     #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
        #     # if i == 0:
        #     #     axs[i,1].legend(fontsize=legend_fontsize, 
        #     #                     framealpha=0.0,
        #     #                     loc='center',
        #     #                     bbox_to_anchor=(0.55,0.5))
        #     for j in range(len(sim.plot.time)):
        #         if sim.plot.time[j] % 0.1 < sim.dt:
        #             axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
        #                           [sim.plot.p[j,1], sim.plot.f2[j,1]],
        #                           'k:')
        #             # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
        #             #               marker='o', markersize=1.5)
        #     ###
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
        #                   label=r'$\dot{q}_1(t)$')
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
        #                   label=r'$\dot{q}_2(t)$')
        #     axs[i,2].grid()
        #     axs[i,2].set_xlim(prm.ti,prm.tf)
        #     axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
        #     if i == 0:
        #         axs[i,2].set_yticks([-10,0,10,20,30])
        #     elif i == 1:
        #         axs[i,2].set_yticks([-40,-20,0,20,40])
        #     elif i in {2,3}:
        #         axs[i,2].set_yticks([-20,-10,0,10])
        #     #axs[i,2].set_yticks([-2,0,2,4])
        #     #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
        #     #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
        #     if i == 0:
        #         axs[i,2].legend(fontsize=legend_fontsize, 
        #                         framealpha=0.0,
        #                         loc='upper left',
        #                         bbox_to_anchor=(-0.03,1.05))
            
        #     for j in range(2):
        #         for tick in axs[i,j+1].xaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
        #         for tick in axs[i,j+1].yaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
    
        # #fig.align_ylabels(axs[:,0])
        # #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
        # fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        
        # fig_num += 1
        # if (prm.save_path != None) & (prm.save_figure == 1):
        #     file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_varying_dampings.{prm.figure_format}')
        #     plt.savefig(file_name, format=prm.figure_format)
    
        #%% pi1-PIK Solution with Imperfect Projections
        
        # epsilon = 0.01
        # lambda0 = [0.3, 0.2, 0.2, 0.2]
        # dt = [0.01, 0.01, 0.001, 0.0001]
        # prm.control_method = 3 # pi1-PIK solution with imperfect projections
        
        # fig, axs = plt.subplots(
        #     len(dt),3,
        #     figsize=figsize,
        #     sharex='col',
        #     gridspec_kw={'width_ratios': [0.5,1,2]}
        #     )
        
        # for i in range(len(dt)):
        #     prm.control_parameter = [epsilon, lambda0[i], lambda0[i]]
        #     prm.dt = dt[i]
        #     sim = LpcSimulation(prm, plot=False)
        #     ###
        #     axs[i,0].set_xlim(-1,1)
        #     axs[i,0].set_ylim(-1,1)
        #     axs[i,0].set_xticks([])
        #     axs[i,0].set_yticks([])
        #     axs[i,0].set_frame_on(False)
        #     axs[i,0].text(
        #         0,0,
        #         r'$\epsilon=%g$'%epsilon+'\n'+r'$\lambda = %g$'%lambda0[i]+'\n'+r'$\delta = %g$'%dt[i],
        #         ha='center', va='center',
        #         fontsize=title_fontsize)
        #     ###
        #     axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
        #                   label=r'$\mathbf{p}(t)$')
        #     axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
        #                   label=r'$\mathbf{f}(\mathbf{q}(t))$')
        #     axs[i,1].grid()
        #     axs[i,1].set_aspect('equal')
        #     axs[i,1].set_xlim(0.7,1.3)
        #     axs[i,1].set_ylim(-0.3,0.3)
        #     axs[i,1].set_xticks([0.7,1,1.3])
        #     axs[i,1].set_yticks([-0.3,0,0.3])
        #     #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
        #     #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
        #     # if i == 0:
        #     #     axs[i,1].legend(fontsize=legend_fontsize, 
        #     #                     framealpha=0.0,
        #     #                     loc='center',
        #     #                     bbox_to_anchor=(0.55,0.5))
        #     for j in range(len(sim.plot.time)):
        #         if sim.plot.time[j] % 0.1 < sim.dt:
        #             axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
        #                           [sim.plot.p[j,1], sim.plot.f2[j,1]],
        #                           'k:')
        #             # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
        #             #               marker='o', markersize=1.5)
        #     ###
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
        #                   label=r'$\dot{q}_1(t)$')
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
        #                   label=r'$\dot{q}_2(t)$')
        #     axs[i,2].grid()
        #     axs[i,2].set_xlim(prm.ti,prm.tf)
        #     axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
        #     if i in {0,2,3}:
        #         axs[i,2].set_yticks([-4,-2,0,2,4])
        #     elif i == 1:
        #         axs[i,2].set_yticks([-10,-5,0,5,10])
        #     #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
        #     #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
        #     if i == 0:
        #         axs[i,2].legend(fontsize=legend_fontsize, 
        #                         framealpha=0.0,
        #                         loc='upper left',
        #                         bbox_to_anchor=(-0.03,1.05))
            
        #     for j in range(2):
        #         for tick in axs[i,j+1].xaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
        #         for tick in axs[i,j+1].yaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
    
        # #fig.align_ylabels(axs[:,0])
        # #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
        # fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        
        # fig_num += 1
        # if (prm.save_path != None) & (prm.save_figure == 1):
        #     file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_imperfect_projections.{prm.figure_format}')
        #     plt.savefig(file_name, format=prm.figure_format)
        
        #%% pi1-PIK Solution with Varying Dampings with varying mu
        
        # mu_max = [0.03, 0.02, 0.02, 0.02]
        # dt = [0.01, 0.01, 0.001, 0.001]
        # mu_min = [mu/10 for mu in mu_max]
        
        # nu = 1
        # rate = [1/(10*a) for a in dt]
        # #rate = [10 for i in range(len(dt))]
        # prm.control_method = 5 # pi1-PIK solution with nonuniform varying dampings
        
        # fig, axs = plt.subplots(
        #     len(dt),3,
        #     figsize=figsize,
        #     sharex='col',
        #     gridspec_kw={'width_ratios': [0.5,1,2]}
        #     )
        
        # for i in range(len(dt)):
        #     prm.control_parameter = [mu_min[i], mu_min[i], mu_max[i], mu_max[i], rate[i], nu]
        #     prm.dt = dt[i]
        #     sim = LpcSimulation(prm, plot=False)
        #     ###
        #     axs[i,0].set_xlim(-1,1)
        #     axs[i,0].set_ylim(-1,1)
        #     axs[i,0].set_xticks([])
        #     axs[i,0].set_yticks([])
        #     axs[i,0].set_frame_on(False)
        #     axs[i,0].text(
        #         0,0,
        #         r'$\mu_{\mathrm{max}} = %g$'%mu_max[i]+'\n'+r'$\delta = %g$'%dt[i],
        #         ha='center', va='center',
        #         fontsize=title_fontsize)
        #     ###
        #     axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
        #                   label=r'$\mathbf{p}(t)$')
        #     axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
        #                   label=r'$\mathbf{f}(\mathbf{q}(t))$')
        #     axs[i,1].grid()
        #     axs[i,1].set_aspect('equal')
        #     axs[i,1].set_xlim(0.7,1.3)
        #     axs[i,1].set_ylim(-0.3,0.3)
        #     axs[i,1].set_xticks([0.7,1,1.3])
        #     axs[i,1].set_yticks([-0.3,0,0.3])
        #     #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
        #     #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
        #     # if i == 0:
        #     #     axs[i,1].legend(fontsize=legend_fontsize, 
        #     #                     framealpha=0.0,
        #     #                     loc='center',
        #     #                     bbox_to_anchor=(0.55,0.5))
        #     for j in range(len(sim.plot.time)):
        #         if sim.plot.time[j] % 0.1 < sim.dt:
        #             axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
        #                           [sim.plot.p[j,1], sim.plot.f2[j,1]],
        #                           'k:')
        #             # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
        #             #               marker='o', markersize=1.5)
        #     ###
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
        #                   label=r'$\dot{q}_1(t)$')
        #     axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
        #                   label=r'$\dot{q}_2(t)$')
        #     # axs[i,2].plot(sim.plot.time, sim.plot.lambda_squared[:,0], 'k--',
        #     #               label=r'$\dot{q}_1(t)$')
        #     # axs[i,2].plot(sim.plot.time, sim.plot.lambda_squared[:,1], 'k',
        #     #               label=r'$\dot{q}_2(t)$')
        #     # axs[i,2].plot(sim.plot.time, sim.plot.mu[:,0], 'k--',
        #     #               label=r'$\dot{q}_1(t)$')
        #     # axs[i,2].plot(sim.plot.time, sim.plot.mu[:,1], 'k',
        #     #               label=r'$\dot{q}_2(t)$')
        #     # axs[i,2].set_yscale('log')
        #     axs[i,2].grid()
        #     axs[i,2].set_xlim(prm.ti,prm.tf)
        #     axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
        #     #axs[i,2].set_yticks([-2,0,2,4])
        #     #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
        #     #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
        #     if i == 0:
        #         axs[i,2].legend(fontsize=legend_fontsize, 
        #                         framealpha=0.0,
        #                         loc='upper left',
        #                         bbox_to_anchor=(-0.03,1.05))
            
        #     for j in range(2):
        #         for tick in axs[i,j+1].xaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
        #         for tick in axs[i,j+1].yaxis.get_major_ticks():
        #             tick.label.set_fontsize(tick_fontsize)
    
        # #fig.align_ylabels(axs[:,0])
        # #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
        # fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        
        # fig_num += 1
        # if (prm.save_path != None) & (prm.save_figure == 1):
        #     file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_varying_dampings_and_mus.{prm.figure_format}')
        #     plt.savefig(file_name, format=prm.figure_format)
         
        #%% Finalization
        plt.show()
