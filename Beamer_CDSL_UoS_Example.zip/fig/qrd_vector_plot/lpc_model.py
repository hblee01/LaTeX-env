# -*- coding: utf-8 -*-

import numpy as np

class LpcTwoLinkManipulator:
    """Defines a two-link manipulator.
    """
    def __init__(self, 
                 l1=0.5, l2=0.5, 
                 q1=0.0, q2=0.0, 
                 dq1=0.0, dq2=0.0):
        self.l = np.array([l1, l2])
        self.q = np.array([q1, q2])
        self.dq = np.array([dq1, dq2])
        
        self.update(self.q, self.dq)
        
    def update(self, q, dq):
        ret = self.forward_kinematics(self.l, q, dq)
        
        self.f1 = ret[0]; self.J1 = ret[1]; self.df1 = ret[2]
        self.f2 = ret[3]; self.J2 = ret[4]; self.df2 = ret[5]
        
    @staticmethod
    def forward_kinematics(l, q, dq, option='all'):
        l1 = l[0]; l2 = l[1]
        q1 = q[0]; q12 = q[0] + q[1]
        C1 = np.cos(q1); S1 = np.sin(q1)
        C12 = np.cos(q12); S12 = np.sin(q12)
        l1C1 = l1*C1; l1S1 = l1*S1
        l2S12 = l2*S12; l2C12 = l2*C12
        l1C1pl2C12 = l1C1 + l2C12; l1S1pl2S12 = l1S1 + l2S12
        
        if option == 'all':
            f1 = np.array([l1C1, l1S1])
            J1 = np.array([[-l1S1, 0.0],
                           [l1C1, 0.0]])
            df1 = np.array([-l1S1 * q1, l1C1 * q1])
            
            f2 = np.array([l1C1pl2C12, l1S1pl2S12])
            J2 = np.array([[-l1S1pl2S12, -l2S12],
                           [l1C1pl2C12, l2C12]])
            df2 = J2 @ dq
            
            return f1, J1, df1, f2, J2, df2
        elif option == 'ee':
            f2 = np.array([l1C1pl2C12, l1S1pl2S12])
            J2 = np.array([[-l1S1pl2S12, -l2S12],
                           [l1C1pl2C12, l2C12]])
            
            return f2, J2