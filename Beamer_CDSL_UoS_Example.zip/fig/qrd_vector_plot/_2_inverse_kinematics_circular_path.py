# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rc('text', usetex=True)

import itertools        # for multi-processing nested for loops
import multiprocessing  # for multi-processing nested for loops
from functools import partial

import os

from lpc_simulation import LpcSimulation
from lpc_plot import LpcPlot

class InverseKinematicsCircularPath():
    
    #%% init
    def __init__(self, prm):
        print("""
InverseKinematicsCircularPath starts:
        """)
        #%% Figure Parameters
        title_fontsize = 22
        #label_fontsize = 25
        tick_fontsize = 20
        legend_fontsize = 18
        
        figsize = [prm.figure_size[0], prm.figure_size[1]/2]
        fig_num = -1
        
        prm.task_method = 1 # circular path
        
        damped_pseudoinverse_solution = 1
        pi1_PIK_solution_with_constant_dampings = 1
        pi1_PIK_solution_with_varying_dampings = 1
        pi1_PIK_solution_with_varying_dampings2 = 1
        pi1_PIK_solution_with_imperfect_projections = 0
        
        quiver_plot = 1
        
        #%% Dmped Pseudoinvese Solution
        
        if damped_pseudoinverse_solution == 1:
            # lambda0 = [0.05, 0.04, 0.04, 0.04]
            # dt = [0.01, 0.01, 0.001, 0.0001]
            #lambda0 = [0.0446, 0.0446]
            lambda0 = [0.044, 0.044]
            dt = [0.01, 0.001]
            prm.control_method = 0 # damped pseudoinverse solution
            
            fig, axs = plt.subplots(
                len(dt),3,
                figsize=figsize,
                sharex='col',
                gridspec_kw={'width_ratios': [0.5,1,2]}
                )
            
            for i in range(len(dt)):
                prm.control_parameter = [lambda0[i]]
                prm.dt = dt[i]
                sim = LpcSimulation(prm, plot=False)
                ###
                axs[i,0].set_xlim(-1,1)
                axs[i,0].set_ylim(-1,1)
                axs[i,0].set_xticks([])
                axs[i,0].set_yticks([])
                axs[i,0].set_frame_on(False)
                axs[i,0].text(
                    0,0,
                    r'$\delta = %g$'%dt[i]+'\n'+r'$\lambda = %g$'%lambda0[i],
                    #r'$\delta = %g$'%dt[i],
                    ha='center', va='center',
                    fontsize=title_fontsize)
                ###
                axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
                              label=r'$\mathbf{p}(t)$')
                axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
                              label=r'$\mathbf{f}(\mathbf{q}(t))$')
                axs[i,1].grid()
                axs[i,1].set_aspect('equal')
                axs[i,1].set_xlim(0.7,1.3)
                axs[i,1].set_ylim(-0.3,0.3)
                axs[i,1].set_xticks([0.7,1,1.3])
                axs[i,1].set_yticks([-0.3,0,0.3])
                #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
                #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
                # if i == 0:
                #     axs[i,1].legend(fontsize=legend_fontsize, 
                #                     framealpha=0.0,
                #                     loc='center',
                #                     bbox_to_anchor=(0.55,0.5))
                for j in range(len(sim.plot.time)):
                    if sim.plot.time[j] % 0.1 < sim.dt:
                        axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
                                      [sim.plot.p[j,1], sim.plot.f2[j,1]],
                                      'k:')
                        # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
                        #               marker='o', markersize=1.5)
                ###
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
                              label=r'$\dot{q}_1(t)$')
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
                              label=r'$\dot{q}_2(t)$')
                axs[i,2].grid()
                axs[i,2].set_xlim(prm.ti,prm.tf)
                axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
                if i == 0:
                    axs[i,2].set_yticks([-20,-10,0,10,20])
                elif i == 1:
                    axs[i,2].set_yticks([-6,-3,0,3,6])
                #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
                #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
                if i == 0:
                    axs[i,2].legend(fontsize=legend_fontsize, 
                                    framealpha=0.0,
                                    loc='upper left',
                                    bbox_to_anchor=(-0.03,1.05))
                
                for j in range(2):
                    for tick in axs[i,j+1].xaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                    for tick in axs[i,j+1].yaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                        
                # if (quiver_plot == 1) & (i == 0):
                #     #snapshot_times = np.linspace(2,3,11)
                #     snapshot_times = np.linspace(2.6,2.5,11)
                #     q_center = np.array([6, 0]) * np.pi / 180.0
                #     q_offset = np.array([6, 6]) * np.pi / 180.0
                #     quiver_num = [21, int(round(21*q_offset[1]/q_offset[0]))]
                #     quiver_scale = 50
                #     fig_quiver, axs_quiver = self.quiver_plot(
                #         snapshot_times,
                #         q_center,
                #         q_offset,
                #         quiver_num,
                #         quiver_scale,
                #         sim,
                #         prm.task_method,
                #         prm.control_method)
                #     for j in range(len(snapshot_times)):
                #         fig_num += 1
                #         if (prm.save_path != None) & (prm.save_figure == 1):
                #             file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_damped_pseudoinverse_solution_quiver{snapshot_times[j]}.{prm.figure_format}')
                #             fig_quiver[j].savefig(file_name, format=prm.figure_format)
        
            #fig.align_ylabels(axs[:,0])
            #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
            fig.tight_layout(pad=0, w_pad=0, h_pad=0)
            
            fig_num += 1
            if (prm.save_path != None) & (prm.save_figure == 1):
                file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_damped_pseudoinverse_solution.{prm.figure_format}')
                fig.savefig(file_name, format=prm.figure_format)
                
        #%% pi1-PIK Solution with Constant Damping
        
        if pi1_PIK_solution_with_constant_dampings == 1:
            # lambda0 = [0.6, 0.5, 0.5, 0.5]
            # dt = [0.01, 0.01, 0.001, 0.0001]
            #lambda0 = [0.57, 0.57]
            #lambda0 = [0.5, 0.5]
            lambda0 = [0.3, 0.3]
            dt = [0.01, 0.001]
            #dt = [0.0001, 0.00001]
            prm.control_method = 2 # pi1-PIK solution with constant damping
            
            fig, axs = plt.subplots(
                len(dt),3,
                figsize=figsize,
                sharex='col',
                gridspec_kw={'width_ratios': [0.5,1,2]}
                )
            
            for i in range(len(dt)):
                prm.control_parameter = [lambda0[i], lambda0[i]]
                prm.dt = dt[i]
                sim = LpcSimulation(prm, plot=False)
                ###
                axs[i,0].set_xlim(-1,1)
                axs[i,0].set_ylim(-1,1)
                axs[i,0].set_xticks([])
                axs[i,0].set_yticks([])
                axs[i,0].set_frame_on(False)
                axs[i,0].text(
                    0,0,
                    r'$\delta = %g$'%dt[i]+'\n'+r'$\lambda_i = %g$'%lambda0[i],
                    #r'$\delta = %g$'%dt[i],
                    ha='center', va='center',
                    fontsize=title_fontsize)
                ###
                axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
                              label=r'$\mathbf{p}(t)$')
                axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
                              label=r'$\mathbf{f}(\mathbf{q}(t))$')
                axs[i,1].grid()
                axs[i,1].set_aspect('equal')
                axs[i,1].set_xlim(0.7,1.3)
                axs[i,1].set_ylim(-0.3,0.3)
                axs[i,1].set_xticks([0.7,1,1.3])
                axs[i,1].set_yticks([-0.3,0,0.3])
                #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
                #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
                # if i == 0:
                #     axs[i,1].legend(fontsize=legend_fontsize, 
                #                     framealpha=0.0,
                #                     loc='center',
                #                     bbox_to_anchor=(0.55,0.5))
                for j in range(len(sim.plot.time)):
                    if sim.plot.time[j] % 0.1 < sim.dt:
                        axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
                                      [sim.plot.p[j,1], sim.plot.f2[j,1]],
                                      'k:')
                        # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
                        #               marker='o', markersize=1.5)
                ###
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
                              label=r'$\dot{q}_1(t)$')
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
                              label=r'$\dot{q}_2(t)$')
                axs[i,2].grid()
                axs[i,2].set_xlim(prm.ti,prm.tf)
                axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
                axs[i,2].set_yticks([-2,0,2,4])
                # if i == 0:
                #     axs[i,2].set_yticks([-50,-25,0,25,50])
                # elif i == 1:
                #     axs[i,2].set_yticks([-20,-10,0,10,20])
                #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
                #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
                if i == 0:
                    axs[i,2].legend(fontsize=legend_fontsize, 
                                    framealpha=0.0,
                                    loc='upper left',
                                    bbox_to_anchor=(-0.03,1.05))
                
                for j in range(2):
                    for tick in axs[i,j+1].xaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                    for tick in axs[i,j+1].yaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                        
                if (quiver_plot == 1) & (i == 0):
                    #snapshot_times = np.linspace(3,2.9,11)
                    snapshot_times = np.array([2.97, 2.25, 1.9, 1.86])
                    q_center = np.array([0.4, 0]) * np.pi / 180.0
                    q_offset = np.array([2, 1.2]) * np.pi / 180.0
                    quiver_num = [21, int(round(21*q_offset[1]/q_offset[0]))]
                    quiver_scale = 8
                    xticks = [-1, 0, 1, 2]
                    yticks = [-1, 0, 1]
                    fig_quiver, axs_quiver = self.quiver_plot(
                        snapshot_times,
                        q_center,
                        q_offset,
                        quiver_num,
                        quiver_scale,
                        sim,
                        prm.task_method,
                        prm.control_method,
                        xticks, yticks, False, (9,5.5))
                    for j in range(len(snapshot_times)):
                        if (prm.save_path != None) & (prm.save_figure == 1):
                            snapshot_time = '%g'%snapshot_times[j]
                            snapshot_time = snapshot_time.replace('.', 'p')
                            file_name = os.path.join(
                                prm.save_path,
                                f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_constant_dampings_quiver{snapshot_time}.{prm.figure_format}')
                            fig_quiver[j].savefig(file_name, format=prm.figure_format)
        
            #fig.align_ylabels(axs[:,0])
            #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
            fig.tight_layout(pad=0, w_pad=0, h_pad=0)
            
            fig_num += 1
            if (prm.save_path != None) & (prm.save_figure == 1):
                file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_constant_dampings.{prm.figure_format}')
                fig.savefig(file_name, format=prm.figure_format)
        
        #%% pi1-PIK Solution with Varying Dampings
        
        if pi1_PIK_solution_with_varying_dampings == 1:
            nu = 1
            # mu = [0.02, 0.01, 0.01, 0.01]
            # dt = [0.01, 0.01, 0.001, 0.0001]
            mu = [0.01, 0.01]
            dt = [0.01, 0.001]
            prm.control_method = 4 # pi1-PIK solution with varying dampings
            
            fig, axs = plt.subplots(
                len(dt),3,
                figsize=figsize,
                sharex='col',
                gridspec_kw={'width_ratios': [0.5,1,2]}
                )
            
            for i in range(len(dt)):
                prm.control_parameter = [mu[i], mu[i], nu]
                prm.dt = dt[i]
                sim = LpcSimulation(prm, plot=False)
                ###
                axs[i,0].set_xlim(-1,1)
                axs[i,0].set_ylim(-1,1)
                axs[i,0].set_xticks([])
                axs[i,0].set_yticks([])
                axs[i,0].set_frame_on(False)
                axs[i,0].text(
                    0,0,
                    r'$\delta = %g$'%dt[i]+'\n'+r'$\mu_i = %g$'%mu[i]+'\n'+r'$\nu = %g$'%nu,
                    #r'$\delta = %g$'%dt[i],
                    ha='center', va='center',
                    fontsize=title_fontsize)
                ###
                axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
                              label=r'$\mathbf{p}(t)$')
                axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
                              label=r'$\mathbf{f}(\mathbf{q}(t))$')
                axs[i,1].grid()
                axs[i,1].set_aspect('equal')
                axs[i,1].set_xlim(0.7,1.3)
                axs[i,1].set_ylim(-0.3,0.3)
                axs[i,1].set_xticks([0.7,1,1.3])
                axs[i,1].set_yticks([-0.3,0,0.3])
                #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
                #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
                # if i == 0:
                #     axs[i,1].legend(fontsize=legend_fontsize, 
                #                     framealpha=0.0,
                #                     loc='center',
                #                     bbox_to_anchor=(0.55,0.5))
                for j in range(len(sim.plot.time)):
                    if sim.plot.time[j] % 0.1 < sim.dt:
                        axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
                                      [sim.plot.p[j,1], sim.plot.f2[j,1]],
                                      'k:')
                        # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
                        #               marker='o', markersize=1.5)
                ###
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
                              label=r'$\dot{q}_1(t)$')
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
                              label=r'$\dot{q}_2(t)$')
                axs[i,2].grid()
                axs[i,2].set_xlim(prm.ti,prm.tf)
                axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
                if i == 0:
                    axs[i,2].set_yticks([-40,-20,0,20,40])
                elif i ==1:
                    axs[i,2].set_yticks([-20,-10,0,10])
                #axs[i,2].set_yticks([-2,0,2,4])
                #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
                #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
                if i == 0:
                    axs[i,2].legend(fontsize=legend_fontsize, 
                                    framealpha=0.0,
                                    loc='upper left',
                                    bbox_to_anchor=(-0.03,1.05))
                
                for j in range(2):
                    for tick in axs[i,j+1].xaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                    for tick in axs[i,j+1].yaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                        
                # if (quiver_plot == 1) & (i == 0):
                #     snapshot_times = np.linspace(2.4,2.3,11)
                #     q_center = np.array([0, 0])
                #     q_offset = np.array([2, 2]) * np.pi / 180.0
                #     quiver_num = [21, 21]
                #     quiver_scale = 20
                #     fig_i, axs_i = self.quiver_plot(snapshot_times,
                #                                     q_center,
                #                                     q_offset,
                #                                     quiver_num,
                #                                     quiver_scale,
                #                                     sim,
                #                                     prm.task_method,
                #                                     prm.control_method)
        
            #fig.align_ylabels(axs[:,0])
            #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
            fig.tight_layout(pad=0, w_pad=0, h_pad=0)
            
            fig_num += 1
            if (prm.save_path != None) & (prm.save_figure == 1):
                file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_varying_dampings.{prm.figure_format}')
                fig.savefig(file_name, format=prm.figure_format)
                
            fig, axs = plt.subplots(2,1)
            axs[0].plot(sim.plot.time, np.sqrt(sim.plot.lambda_squared[:,0]))
            axs[1].plot(sim.plot.time, np.sqrt(sim.plot.lambda_squared[:,1]))
            for i in range(2):
                axs[i].grid()
                axs[i].set_yscale('log')
                
        #%% pi1-PIK Solution with Varying Dampings with varying mu
        
        if pi1_PIK_solution_with_varying_dampings2 == 1:
            # mu_max = [0.03, 0.02, 0.02, 0.02]
            # dt = [0.01, 0.01, 0.001, 0.0001]
            mu_max = [0.02, 0.02]
            dt = [0.01, 0.001]
            mu_min = [mu/10 for mu in mu_max]
            
            nu = 1
            rate = [1/(10*a) for a in dt]
            #rate = [10 for i in range(len(dt))]
            prm.control_method = 5 # pi1-PIK solution with nonuniform varying dampings
            
            fig, axs = plt.subplots(
                len(dt),3,
                figsize=figsize,
                sharex='col',
                gridspec_kw={'width_ratios': [0.5,1,2]}
                )
            
            for i in range(len(dt)):
                prm.control_parameter = [mu_min[i], mu_min[i], mu_max[i], mu_max[i], rate[i], nu]
                prm.dt = dt[i]
                sim = LpcSimulation(prm, plot=False)
                ###
                axs[i,0].set_xlim(-1,1)
                axs[i,0].set_ylim(-1,1)
                axs[i,0].set_xticks([])
                axs[i,0].set_yticks([])
                axs[i,0].set_frame_on(False)
                axs[i,0].text(
                    0,0,
                    r'$\delta = %g$'%dt[i]+'\n'+r'$\overline{\mu}_i = %g$'%mu_max[i]+'\n'
                    +r'$\underline{\mu}_i = %g$'%mu_min[i]+'\n'+r'$\alpha_i = %g$'%rate[i]+'\n'
                    +r'$\nu = %g$'%nu,
                    #r'$\delta = %g$'%dt[i],
                    ha='center', va='center',
                    fontsize=title_fontsize)
                ###
                axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
                              label=r'$\mathbf{p}(t)$')
                axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
                              label=r'$\mathbf{f}(\mathbf{q}(t))$')
                axs[i,1].grid()
                axs[i,1].set_aspect('equal')
                axs[i,1].set_xlim(0.7,1.3)
                axs[i,1].set_ylim(-0.3,0.3)
                axs[i,1].set_xticks([0.7,1,1.3])
                axs[i,1].set_yticks([-0.3,0,0.3])
                #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
                #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
                # if i == 0:
                #     axs[i,1].legend(fontsize=legend_fontsize, 
                #                     framealpha=0.0,
                #                     loc='center',
                #                     bbox_to_anchor=(0.55,0.5))
                for j in range(len(sim.plot.time)):
                    if sim.plot.time[j] % 0.1 < sim.dt:
                        axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
                                      [sim.plot.p[j,1], sim.plot.f2[j,1]],
                                      'k:')
                        # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
                        #               marker='o', markersize=1.5)
                ###
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
                              label=r'$\dot{q}_1(t)$')
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
                              label=r'$\dot{q}_2(t)$')
                # axs[i,2].plot(sim.plot.time, sim.plot.lambda_squared[:,0], 'k--',
                #               label=r'$\dot{q}_1(t)$')
                # axs[i,2].plot(sim.plot.time, sim.plot.lambda_squared[:,1], 'k',
                #               label=r'$\dot{q}_2(t)$')
                # axs[i,2].plot(sim.plot.time, sim.plot.mu[:,0], 'k--',
                #               label=r'$\dot{q}_1(t)$')
                # axs[i,2].plot(sim.plot.time, sim.plot.mu[:,1], 'k',
                #               label=r'$\dot{q}_2(t)$')
                # axs[i,2].set_yscale('log')
                axs[i,2].grid()
                axs[i,2].set_xlim(prm.ti,prm.tf)
                axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
                # if i == 0:
                #     axs[i,2].set_yticks([-10,0,10,20,30])
                # elif i == 1:
                #     axs[i,2].set_yticks([-40,-20,0,20,40])
                # elif i == 2:
                #     axs[i,2].set_yticks([-10,0,10,20])
                # elif i == 3:
                #     axs[i,2].set_yticks([-5,0,5,10,15])
                if i == 0:
                    axs[i,2].set_yticks([-50,-25,0,25,50])
                elif i == 1:
                    axs[i,2].set_yticks([-10,0,10,20])
                #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
                #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
                if i == 0:
                    axs[i,2].legend(fontsize=legend_fontsize, 
                                    framealpha=0.0,
                                    loc='upper left',
                                    bbox_to_anchor=(-0.03,1.05))
                
                for j in range(2):
                    for tick in axs[i,j+1].xaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                    for tick in axs[i,j+1].yaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
        
            #fig.align_ylabels(axs[:,0])
            #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
            fig.tight_layout(pad=0, w_pad=0, h_pad=0)
            
            fig_num += 1
            if (prm.save_path != None) & (prm.save_figure == 1):
                file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_varying_dampings_and_mus.{prm.figure_format}')
                fig.savefig(file_name, format=prm.figure_format)
            
        #%% pi1-PIK Solution with Imperfect Projections
        
        if pi1_PIK_solution_with_imperfect_projections == 1:
            epsilon = 0.01
            # lambda0 = [0.3, 0.2, 0.2, 0.2]
            # dt = [0.01, 0.01, 0.001, 0.0001]
            lambda0 = [0.2, 0.2]
            dt = [0.01, 0.001]
            prm.control_method = 3 # pi1-PIK solution with imperfect projections
            
            fig, axs = plt.subplots(
                len(dt),3,
                figsize=figsize,
                sharex='col',
                gridspec_kw={'width_ratios': [0.5,1,2]}
                )
            
            for i in range(len(dt)):
                prm.control_parameter = [epsilon, lambda0[i], lambda0[i]]
                prm.dt = dt[i]
                sim = LpcSimulation(prm, plot=False)
                ###
                axs[i,0].set_xlim(-1,1)
                axs[i,0].set_ylim(-1,1)
                axs[i,0].set_xticks([])
                axs[i,0].set_yticks([])
                axs[i,0].set_frame_on(False)
                axs[i,0].text(
                    0,0,
                    r'$\epsilon=%g$'%epsilon+'\n'+r'$\lambda = %g$'%lambda0[i]+'\n'+r'$\delta = %g$'%dt[i],
                    ha='center', va='center',
                    fontsize=title_fontsize)
                ###
                axs[i,1].plot(sim.plot.p[:,0], sim.plot.p[:,1], 'k--', 
                              label=r'$\mathbf{p}(t)$')
                axs[i,1].plot(sim.plot.f2[:,0], sim.plot.f2[:,1], 'k',
                              label=r'$\mathbf{f}(\mathbf{q}(t))$')
                axs[i,1].grid()
                axs[i,1].set_aspect('equal')
                axs[i,1].set_xlim(0.7,1.3)
                axs[i,1].set_ylim(-0.3,0.3)
                axs[i,1].set_xticks([0.7,1,1.3])
                axs[i,1].set_yticks([-0.3,0,0.3])
                #axs[i,1].set_xlabel(r'$x$', fontsize=label_fontsize)
                #axs[i,1].set_ylabel(r'$y$', fontsize=label_fontsize)
                # if i == 0:
                #     axs[i,1].legend(fontsize=legend_fontsize, 
                #                     framealpha=0.0,
                #                     loc='center',
                #                     bbox_to_anchor=(0.55,0.5))
                for j in range(len(sim.plot.time)):
                    if sim.plot.time[j] % 0.1 < sim.dt:
                        axs[i,1].plot([sim.plot.p[j,0], sim.plot.f2[j,0]],
                                      [sim.plot.p[j,1], sim.plot.f2[j,1]],
                                      'k:')
                        # axs[i,1].plot(sim.plot.p[j,0], sim.plot.p[j,1], 'k',
                        #               marker='o', markersize=1.5)
                ###
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,0], 'k--',
                              label=r'$\dot{q}_1(t)$')
                axs[i,2].plot(sim.plot.time, sim.plot.dq[:,1], 'k',
                              label=r'$\dot{q}_2(t)$')
                axs[i,2].grid()
                axs[i,2].set_xlim(prm.ti,prm.tf)
                axs[i,2].set_xticks(np.linspace(prm.ti,prm.tf,6))
                if i == 0:
                    axs[i,2].set_yticks([-10,-5,0,5,10])
                elif i == 1:
                    axs[i,2].set_yticks([-4,-2,0,2,4])
                # if i in {0,2,3}:
                #     axs[i,2].set_yticks([-4,-2,0,2,4])
                # elif i == 1:
                #     axs[i,2].set_yticks([-10,-5,0,5,10])
                #axs[i,2].set_xlabel(r'$t$', fontsize=label_fontsize)
                #axs[i,2].set_ylabel(r'$q_i(t)$', fontsize=label_fontsize)
                if i == 0:
                    axs[i,2].legend(fontsize=legend_fontsize, 
                                    framealpha=0.0,
                                    loc='upper left',
                                    bbox_to_anchor=(-0.03,1.05))
                
                for j in range(2):
                    for tick in axs[i,j+1].xaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
                    for tick in axs[i,j+1].yaxis.get_major_ticks():
                        tick.label.set_fontsize(tick_fontsize)
        
            #fig.align_ylabels(axs[:,0])
            #fig.tight_layout(pad=0, h_pad=0.2, w_pad=0.5)
            fig.tight_layout(pad=0, w_pad=0, h_pad=0)
            
            fig_num += 1
            if (prm.save_path != None) & (prm.save_figure == 1):
                file_name = os.path.join(prm.save_path,f'inverse_kinematics_plot{fig_num}_pi1-PIK_solution_imperfect_projections.{prm.figure_format}')
                fig.savefig(file_name, format=prm.figure_format)
         
        #%% Finalization
        plt.show()
        
    #%% quiver_plot
    def quiver_plot(self, snapshot_times, q_center, q_offset, quiver_num, quiver_scale, 
                    sim, task_method, control_method, xticks=None, yticks=None,
                    show_time=True, figsize=None):
        fig_i = list(range(len(snapshot_times)))
        axs_i = list(range(len(snapshot_times)))
        for i in range(len(snapshot_times)):
            if figsize == None:
                fig_i[i], axs_i[i] = plt.subplots(figsize=(9,int(round(9*q_offset[1]/q_offset[0]))))
            else:
                fig_i[i], axs_i[i] = plt.subplots(figsize=figsize)
            
        for itr in range(len(snapshot_times)):
            current_time_index = 0
            for i in range(len(sim.plot.time)):
                if snapshot_times[itr] - sim.plot.time[i] < sim.dt:
                    current_time_index = i
                    break
            #q = sim.plot.q[current_time_index]
            
            q1_lim = np.array([q_center[0] - q_offset[0], q_center[0] + q_offset[0]])
            q1_lim_degree = q1_lim * 180 / np.pi
            q2_lim = np.array([q_center[1] - q_offset[1], q_center[1] + q_offset[1]])
            q2_lim_degree = q2_lim * 180 / np.pi
            
            quiver_q1_num = quiver_num[0]
            quiver_q1 = np.linspace(q1_lim[0], q1_lim[1], quiver_q1_num)
            quiver_q1_degree = quiver_q1 * 180 / np.pi
            
            quiver_q2_num = quiver_num[1]
            quiver_q2 = np.linspace(q2_lim[0], q2_lim[1], quiver_q2_num)
            quiver_q2_degree = quiver_q2 * 180 / np.pi
            
            U = np.zeros((1, quiver_q1_num, quiver_q2_num))
            V = np.zeros((1, quiver_q1_num, quiver_q2_num))
            
            paramlist = list(itertools.product([snapshot_times[itr]], quiver_q1, quiver_q2))
            pool = multiprocessing.Pool()
            
            if task_method == 0:
                res = pool.map(partial(LpcPlot.quiver_calculate_u_linear_path,
                                       l=sim.model.l, 
                                       ti=sim.task.ti, 
                                       tf=sim.task.tf, 
                                       c=sim.task.coefficient, 
                                       initial_point=sim.task.initial_point, 
                                       final_point=sim.task.final_point, 
                                       K=sim.task.K, 
                                       method=sim.control.method, 
                                       parameter=sim.control.parameter), 
                                paramlist)
            elif task_method == 1:
                res = pool.map(partial(LpcPlot.quiver_calculate_u_circular_path,
                                       l=sim.model.l, 
                                       ti=sim.task.ti, 
                                       tf=sim.task.tf, 
                                       c=sim.task.coefficient, 
                                       r_c=sim.task.radius, 
                                       p_c=sim.task.center, 
                                       K=sim.task.K, 
                                       method=sim.control.method, 
                                       parameter=sim.control.parameter), 
                                paramlist)
            
            num = 0
            for i in range(quiver_q1_num):
                for j in range(quiver_q2_num):
                    U[0,i,j] = res[num][0]
                    V[0,i,j] = res[num][1]
                    num += 1
            
            axs_i[itr].quiver(quiver_q1_degree, quiver_q2_degree, U[0].T, V[0].T,
                              angles='xy', scale_units='inches', scale=quiver_scale)
            axs_i[itr].plot(sim.plot.q[:current_time_index,0] * 180 / np.pi, 
                            sim.plot.q[:current_time_index,1] * 180 / np.pi,
                            'k--', 
                            marker='o', markevery=1
                            )
            
            axs_i[itr].set_xlim(q1_lim_degree)
            axs_i[itr].set_ylim(q2_lim_degree)
            if xticks == None:
                axs_i[itr].set_xticks(1.0*np.linspace(q1_lim_degree[0],q1_lim_degree[1],5))
            else:
                axs_i[itr].set_xticks(xticks)
            if yticks == None:
                axs_i[itr].set_yticks(1.0*np.linspace(q2_lim_degree[0],q2_lim_degree[1],5))
            else:
                axs_i[itr].set_yticks(yticks)
            axs_i[itr].tick_params(axis='both', which='major', labelsize=30)
            axs_i[itr].grid()
            axs_i[itr].set_aspect('equal')
            if show_time == True:
                axs_i[itr].text(0.9, 0.95, r'$t = %g$'%snapshot_times[itr], 
                                fontsize=30,
                                backgroundcolor='white',
                                horizontalalignment='center',
                                verticalalignment='center',
                                transform = axs_i[itr].transAxes)
            fig_i[itr].tight_layout(pad=0, w_pad=0, h_pad=0)
                
        return fig_i, axs_i
        