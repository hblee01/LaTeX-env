# -*- coding: utf-8 -*-

import numpy as np
import sys
import lpc_task

class LpcControl:
    def __init__(self,
                 dt=0.001,
                 task=lpc_task.LpcTask(),
                 method=None, 
                 parameter=[]):
        self.dt = dt
        self.task = task
        self.method = method
        self.parameter = parameter
        
        if self.method == 4:
            self.lambda_squared = np.zeros(2)
            
        # variables for the varying mu
        if self.method == 5:
            self.mu_min = parameter[0:2]
            self.mu_max = parameter[2:4]
            self.rate = parameter[4]
            self.nu = parameter[5]
            self.mu = self.mu_max.copy()
            self.mu_input = self.mu_max.copy()
            self.lambda_squared = np.zeros(2)
            self.J_past = self.task.J.copy()
            self.cii = np.zeros(2)
            
        self.update(self.task)
            
    def update(self, task):
        if self.method in {0,1,2,3}:
            self.u = self.inverse_kinematics(
                task.J, task.r, self.method, self.parameter)
        elif self.method == 4:
            Q, R = self.qr_mgs(task.J.T)
            C = R.T
            for i in range(2):
                self.lambda_squared[i] = self.parameter[i]**2/C[i,i]**(2*self.parameter[2])
            self.u = self.inverse_kinematics(
                task.J, task.r, self.method, self.parameter)
        elif self.method == 5:
            Q, R = self.qr_mgs(task.J.T)
            C = R.T
            Q, R = self.qr_mgs(self.J_past.T)
            C_past = R.T
            self.J_past = task.J.copy()
            for i in range(2):
                if C[i,i] - C_past[i,i] < 0:
                    self.mu_input[i] = self.mu_max[i]
                else:
                    self.mu_input[i] = self.mu_min[i]
                self.mu[i] = (1-self.dt*self.rate)*self.mu[i] + self.dt*self.rate*self.mu_input[i]
                self.lambda_squared[i] = self.mu[i]**2/C[i,i]**(2*self.nu)
            self.u = self.inverse_kinematics(
                task.J, task.r, self.method, [self.mu[0], self.mu[1], self.nu])
            
    @classmethod
    def inverse_kinematics(cls, J, r, method, parameter):
        J1 = J[0:1,:]; J2 = J[1:2,:]
        r1 = r[0:1]; r2 = r[1:2]
        pinv = np.linalg.pinv

        if method in {2,4,5}:
            Q, R = cls.qr_mgs(J.T)
            #Q, R = np.linalg.qr(J.T)
            C = R.T; Jh = Q.T
            Cd = np.array([[C[0,0], 0], [0, C[1,1]]])
            Cl = C - Cd
            
        if method == None:
            u = np.zeros(2)
        elif method == 0: # damped pseudoinverse solution
            M = J @ J.T + parameter[0]**2 * np.eye(2)
            u = J.T @ pinv(M) @ r
        elif method == 1: # transpose solution
            u = J.T @ r
        elif method == 2: # pi1-PIK solution with constant dampings
            dii = [0,0]
            for i in {0,1}:
                dii[i] = pinv([[C[i,i]**2 + parameter[i]**2]])[0,0]
            D = np.diag(dii)
            invCd = Cd.T @ D
            L = D @ np.linalg.inv(np.eye(2) + Cl @ invCd)
            u = Jh.T @ Cd.T @ L @ r
        
        elif method == 3: # pi1-PIK soluution with imperfect projections
            u = np.zeros(2)
            N = np.eye(2)
            
            pJN = (J1 @ N).T / (J1 @ N @ N @ J1.T + parameter[1]**2)
            u = u + pJN @ (r1 - J1 @ u)
            pJN = (J1 @ N).T / (J1 @ N @ N @ J1.T + parameter[0]**2)
            N = N - pJN @ J1 @ N
                
            pJN = (J2 @ N).T / (J2 @ N @ N @ J2.T + parameter[2]**2)
            u = u + pJN @ (r2 - J2 @ u)
        elif method in {4,5}: # pi1-PIK solution with varying dampings
            dii = [0,0]
            for i in {0,1}:
                #epsilon = 0.000000001
                epsilon = 0
                dii[i] = pinv([[C[i,i]**2 + parameter[i]**2/(C[i,i]**2+epsilon**2)**parameter[2]]])[0,0]
            D = np.diag(dii)
            invCd = Cd.T @ D
            L = D @ np.linalg.inv(np.eye(2) + Cl @ invCd)
            u = Jh.T @ Cd.T @ L @ r
        else:
            print(f'invalid conrol method: method = {method}')
            sys.exit()
            
        return u
    
    @staticmethod
    def qr_mgs(A):
        """
        - QR decomposition algorithm using the modified Gram-Schmit 
          orthogonalization based on Trefethen and Bau, Algorithm 8.1.
        - It provides only the reduced QR decompositions according to the dimension 
          of A.
        - The algorithm is modified to increase the numerical stability
        """
        m, n = A.shape
        epsilon = 0.000000001  # tolerance for the inverse
        
        if n > m:
            print('qrd_mgs requires m >= n!')
            sys.exit()
        
        Q = A.copy()
        R = np.zeros((n,n))
        
        for i in range(n):
            R[i,i] = np.linalg.norm(Q[:,i])
            
            if R[i,i] < epsilon:
                Q[:,i] = np.zeros(m)
            else:
                Q[:,i] = Q[:,i] / R[i,i]
            
            for j in range(i+1, n):
                R[i,j] = Q[:,i].T @ Q[:,j]
                Q[:,j] = Q[:,j]- R[i,j] * Q[:,i]
                
                if (i,j) == (2,3):
                    print('R[i,i] = ', R[i,i])
                    print('Q[:,i] = ', Q[:,i])
                    print('Q[:,j] = ', Q[:,j])
                
        return Q, R
