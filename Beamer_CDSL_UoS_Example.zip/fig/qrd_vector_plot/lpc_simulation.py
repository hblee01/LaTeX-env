# -*- coding: utf-8 -*-

import lpc_model, lpc_task, lpc_control, lpc_plot

global prm

class LpcSimulation:
    def __init__(self, prm, plot=True):
#         print(f"""
# Simulation Starts:
#     ti = {prm.ti}, tf = {prm.tf}, dt = {prm.dt}
#     method = {prm.method}
#     parameter = {prm.parameter}
#         """)
        self.ti = self.t = prm.ti
        self.tf = prm.tf
        self.dt = prm.dt
        
        self.N = round((self.tf - self.ti)/self.dt) # total number of iteration
        self.n = 1
        
        self.model = lpc_model.LpcTwoLinkManipulator(
            prm.l1, prm.l2, prm.q1, prm.q2, prm.dq1, prm.dq2)
        self.task = lpc_task.LpcTask(
            self.model, prm.ti_task, prm.tp_task, prm.clik, 
            prm.task_method, prm.task_parameter)
        self.control = lpc_control.LpcControl(
            self.dt, self.task, prm.control_method, prm.control_parameter)
        self.plot = lpc_plot.LpcPlot(
            prm, self.N, self.model, self.task, self.control)
        
        while self.update():
            pass
            # if self.n % 100 == 0:
            #     print('Simulation Time = %g' % self.t)
                
        #self.plot.save()
        #self.plot.load()
        if plot == True:
            self.plot.plot()

    def update(self):
        self.t += self.dt
        self.n += 1
        self.model.dq = self.control.u
        self.model.q += self.model.dq * self.dt
        self.model.update(self.model.q, self.model.dq)
        self.task.update(self.model, self.t)
        self.control.update(self.task)
        self.plot.update(self.t)
        
        if self.n < self.N:
            return True
        else:
            return False