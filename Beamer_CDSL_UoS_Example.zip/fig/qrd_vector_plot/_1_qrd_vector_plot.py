# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rc('text', usetex=True)

import os

# for multi-processing nested for loops
import itertools        
import multiprocessing
from functools import partial

import lpc_model, lpc_control

class QrdVectorPlot():
    def __init__(self, prm):
        print("""
QrdVectorPlot starts:
              """)
        self.prm = prm
        self.l1 = prm.l1; self.l2 = prm.l2
        self.fig_num = -1
        self.scale1 = 5 # scale of the arrow length
        self.scale2 = 2
        self.figsize = prm.figure_size
        
        q_lim = 100 * np.array([[-1, 1], [-1, 1]]) * np.pi / 180
        contour_num = [100, 100]
        quiver_num = [21, 21]
        
        for i in range(3):
        #for i in range(1):
            if i == 0:
                self.figsize = (9,8.7)
            elif i == 1:
                self.figsize = (9,8.58)
            elif i == 2:
                self.figsize = (9,8.4)
            self.plot(q_lim, contour_num, quiver_num)
            q_lim /= 10
            
        plt.show()
        
    @staticmethod
    def calculate_vectors(q, l):
        f, J = lpc_model.LpcTwoLinkManipulator.forward_kinematics(l, q, np.zeros(2), 'ee')
        Q, R = lpc_control.LpcControl.qr_mgs(J.T)
        C = R.T; Jh = Q.T
        
        v1 = J[0,:] 
        v2 = J[1,:]
        v3 = C[1,0] * Jh[0,:]
        v4 = C[1,1] * Jh[1,:]
        
        return v1, v2, v3, v4  
    
    @staticmethod
    def calculate_f(q, l):
        f, J = lpc_model.LpcTwoLinkManipulator.forward_kinematics(l, q, np.zeros(2), 'ee')
        return f
          
    def plot(self, q_lim, contour_num, quiver_num):
        #%%
        q1_lim = q_lim[0,:]
        q1_lim_degree = q1_lim * 180 / np.pi
        q2_lim = q_lim[1,:]
        q2_lim_degree = q2_lim * 180 / np.pi
        
        #%%
        contour_q1_num = contour_num[0]
        contour_q1 = np.linspace(q1_lim[0], q1_lim[1], contour_q1_num)
        contour_q1_degree = contour_q1 * 180 / np.pi
        
        contour_q2_num = contour_num[1]
        contour_q2 = np.linspace(q2_lim[0], q2_lim[1], contour_q2_num)
        contour_q2_degree = contour_q2 * 180 / np.pi
        
        f = np.zeros((contour_q1_num, contour_q2_num, 2))
        
        paramlist = list(itertools.product(contour_q1, contour_q2))
        pool = multiprocessing.Pool()
        
        res  = pool.map(partial(QrdVectorPlot.calculate_f, 
                                l=[self.l1, self.l2]), 
                        paramlist)
        
        num = 0
        for i in range(contour_q1_num):
            for j in range(contour_q2_num):
                f[i,j] = res[num]
                num += 1
        
        #%%
        quiver_q1_num = quiver_num[0]
        quiver_q1 = np.linspace(q1_lim[0], q1_lim[1], quiver_q1_num)
        quiver_q1_degree = quiver_q1 * 180 / np.pi
        
        quiver_q2_num = quiver_num[1]
        quiver_q2 = np.linspace(q2_lim[0], q2_lim[1], quiver_q2_num)
        quiver_q2_degree = quiver_q2 * 180 / np.pi
        
        U = np.zeros((4, quiver_q1_num, quiver_q2_num))
        V = np.zeros((4, quiver_q1_num, quiver_q2_num))
        
        paramlist = list(itertools.product(quiver_q1, quiver_q2))
        pool = multiprocessing.Pool()
        
        # for i in range(q1_num):
        #     for j in range(q2_num):
        #         U[0,i,j] = q1[i]
        #         V[0,i,j] = q2[j]
        # plt.quiver(q1, q2, U[0,:,:].T, V[0,:,:].T)
        # plt.show()
        
        res  = pool.map(partial(QrdVectorPlot.calculate_vectors, 
                                l=[self.l1, self.l2]), 
                        paramlist)
        
        #v_norm_max = np.zeros(4)
        num = 0
        for i in range(quiver_q1_num):
            for j in range(quiver_q2_num):
                for k in range(4):
                    U[k,i,j] = res[num][k][0]
                    V[k,i,j] = res[num][k][1]
                    #v = np.array([U[k,i,j], V[k,i,j]])
                    #v_norm = np.linalg.norm(v)
                    #if v_norm > v_norm_max[k]:
                    #    v_norm_max[k] = v_norm
                num += 1
                
        #%%
        self.fig_num += 1
        fig, axs = plt.subplots(2,2, figsize=self.figsize)
        num = 0
        for i in range(2):
            for j in range(2):
                axs[i,j].quiver(quiver_q1_degree, quiver_q2_degree, 
                                U[num].T, V[num].T,
                                angles='xy', scale_units='inches', scale=self.scale1)
                
                if num < 2:
                    CS = axs[i,j].contour(contour_q1_degree, contour_q2_degree,
                                          f[:,:,num].T, np.arange(-1,1.2,0.2),
                                          colors='k', 
                                          linewidths=0.5,linestyles='solid')
                    clabels = axs[i,j].clabel(CS, inline=True, fontsize=10)
                    [txt.set_backgroundcolor('white') for txt in clabels]
                
                axs[i,j].set_xlim(q1_lim_degree)
                axs[i,j].set_ylim(q2_lim_degree)
                axs[i,j].set_xticks(0.9*np.linspace(q1_lim_degree[0],q1_lim_degree[1],5))
                axs[i,j].set_yticks(0.9*np.linspace(q2_lim_degree[0],q2_lim_degree[1],5))
                axs[i,j].tick_params(axis='both', which='major', labelsize=12)
                axs[i,j].grid()
                axs[i,j].set_aspect('equal')
                num += 1
        fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        
        if (self.prm.save_path != None) & (self.prm.save_figure == 1):
            file_name = os.path.join(
                self.prm.save_path, 
                f'qrd_vector_plot{self.fig_num}_basic_plots'
                + f'.{self.prm.figure_format}')
            plt.savefig(file_name, format=self.prm.figure_format)
        
        #%%
        plot_name = ['j1', 'j2', 'c21jh1', 'c22jh2']
        for i in range(4):
            self.fig_num += 1
            fig, axs = plt.subplots(figsize=self.figsize)
            axs.quiver(quiver_q1_degree, quiver_q2_degree, U[i].T, V[i].T,
                        angles='xy', scale_units='inches', scale=self.scale2)
            
            if i < 2:
                CS = axs.contour(contour_q1_degree, contour_q2_degree,
                                 f[:,:,i].T, np.arange(-1,1.2,0.2),
                                 colors='k', 
                                 linewidths=1,linestyles='solid')
                clabels = axs.clabel(CS, inline=True, #inline_spacing=10,
                                     fontsize=30, fmt=r'$%1.1f$')
                [txt.set_backgroundcolor('white') for txt in clabels]
            
            axs.set_xlim(q1_lim_degree)
            axs.set_ylim(q2_lim_degree)
            axs.set_xticks(0.9*np.linspace(q1_lim_degree[0],q1_lim_degree[1],5))
            axs.set_yticks(0.9*np.linspace(q2_lim_degree[0],q2_lim_degree[1],5))
            axs.tick_params(axis='both', which='major', labelsize=40)
            axs.grid()
            axs.set_aspect('equal')
            fig.tight_layout(pad=0, w_pad=0, h_pad=0)
            
            if (self.prm.save_path != None) & (self.prm.save_figure == 1):
                file_name = os.path.join(
                    self.prm.save_path,
                    f'qrd_vector_plot{self.fig_num}_'
                    + f'{plot_name[i]}.{self.prm.figure_format}')
                plt.savefig(file_name, format=self.prm.figure_format)