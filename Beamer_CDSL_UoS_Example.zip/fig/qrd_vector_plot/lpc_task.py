# -*- coding: utf-8 -*-

import numpy as np
import lpc_model

class LpcTask:
    def __init__(self, 
                 model=lpc_model.LpcTwoLinkManipulator(),
                 ti=0.0, tp=1.0, clik=[10.0, 10.0], method=None, parameter=[]):
        self.model = model
        self.ti = ti
        self.tf = ti + tp
        self.K = np.diag(clik)
        self.method = method
        self.parameter = parameter
        
        if self.method == 0: # linear path
            L = np.sum(model.l)
            p_i = model.f2
            p_c = np.array([L,0.0])
            #p_f = p_i + 2 * (p_c - p_i)
            p_f = p_i + 1.1 * (p_c - p_i)
            #p_f = p_c
            
            self.initial_point = p_i
            self.final_point = p_f
            
            tp1 = tp/2;
            tp2 = tp1*tp1;
            tp3 = tp2*tp1;
            tp4 = tp3*tp1;
            tp5 = tp4*tp1;
            
            dist_i = 0
            dist_f = np.linalg.norm(p_f-p_i)
            ddist_i = ddist_f = 0.0
            dddist_i = dddist_f = 0.0
                
            c0 = dist_i;
            c1 = ddist_i;
            c2 = dddist_i/2;
            c3 = ( 20*(dist_f-dist_i) - (8*ddist_f+12*ddist_i)*tp1 \
                  - (3*dddist_i-dddist_f)*tp2 )/(2*tp3)
            c4 = ( 30*(dist_i-dist_f) + (14*ddist_f+16*ddist_i)*tp1 \
                  + (3*dddist_i-2*dddist_f)*tp2 )/(2*tp4)
            c5 = ( 12*(dist_f-dist_i) - (6*ddist_f+6*ddist_i)*tp1 \
                  - (dddist_i-dddist_f)*tp2 )/(2*tp5)
                    
            self.coefficient = np.array([c0,c1,c2,c3,c4,c5])
            
        elif self.method == 1: # circular path
            L = np.sum(model.l)
            [x,y] = model.f2
            r_max = np.sqrt((L-x)**2 + y**2)
            if L-x == 0:
                r_min = 0
            else:
                r_min = (y**2 + (L-x)**2)/(2*(L-x)) # (L-r-x)^2 + y^2 = r^2
            ratio = 1.0
            r = (1-ratio)*r_min + ratio*r_max
            
            self.radius = r
            self.center = np.array([x+np.sqrt(r**2-y**2),0.0])
            
            p_i = model.f2
            p_c = self.center
            p = p_i - p_c
            th_i = np.arctan2(p[1], p[0])
            th_f = th_i + 2*np.pi
            dth_i = dth_f = 0.0
            ddth_i = ddth_f = 0.0
            
            tp1 = tp;
            tp2 = tp1*tp1;
            tp3 = tp2*tp1;
            tp4 = tp3*tp1;
            tp5 = tp4*tp1;
            
            c0 = th_i;
            c1 = dth_i;
            c2 = ddth_i/2;
            c3 = ( 20*(th_f-th_i) - (8*dth_f+12*dth_i)*tp1 \
                  - (3*ddth_i-ddth_f)*tp2 )/(2*tp3)
            c4 = ( 30*(th_i-th_f) + (14*dth_f+16*dth_i)*tp1 \
                  + (3*ddth_i-2*ddth_f)*tp2 )/(2*tp4)
            c5 = ( 12*(th_f-th_i) - (6*dth_f+6*dth_i)*tp1 \
                  - (ddth_i-ddth_f)*tp2 )/(2*tp5)
                
            self.coefficient = np.array([c0, c1, c2, c3, c4, c5])
        else:
            self.coefficient = np.zeros(6)
            
        self.update(self.model, ti)
        
    def update(self, model, t):
        self.f = model.f2; self.J = model.J2; self.df = model.df2
        
        if self.method == 0:
            ret = self.calculate_task_linear(
                self.ti, self.tf, t, self.coefficient, 
                self.initial_point, self.final_point, model.f2, self.K)
        elif self.method == 1:
            ret = self.calculate_task_circular(
                self.ti, self.tf, t, self.coefficient, 
                self.radius, self.center, model.f2, self.K)
        else:
            ret = (np.zeros(2), np.zeros(2), np.zeros(2))
        
        self.p = ret[0]; self.dp = ret[1]; self.r = ret[2]
    
    @staticmethod
    def calculate_task_linear(ti, tf, t, c, initial_point, final_point, f, K, option='all'):
        if t < ti:
            t = ti
        if t > tf:
            t = tf
            
        if t < (ti+tf)/2:
            tp1 = t - ti
            start_point = initial_point
            direction = (final_point - initial_point)/np.linalg.norm(final_point-initial_point)
        else:
            tp1 = t - (ti+tf)/2
            start_point = final_point
            direction = (initial_point - final_point)/np.linalg.norm(initial_point-final_point)
            
        tp2 = tp1*tp1
        tp3 = tp2*tp1
        tp4 = tp3*tp1
        tp5 = tp4*tp1
            
        dist = c[0] + c[1]*tp1 + c[2]*tp2 + c[3]*tp3 + c[4]*tp4 + c[5]*tp5
        ddist = c[1] + 2*c[2]*tp1 + 3*c[3]*tp2 + 4*c[4]*tp3 + 5*c[5]*tp4
        #dddist = 2*c[2] + 6*c[3]*tp1 + 12*c[4]*tp2 + 20*c[5]*tp3

        p = start_point + dist * direction
        dp = ddist * direction
        #ddp = dddist * direction
        
        r = dp + K @ (p - f)
        
        if option == 'all':
            return p, dp, r
        elif option == 'reference':
            return r
        
    @staticmethod
    def calculate_task_circular(ti, tf, t, c, r_c, p_c, f, K, option='all'):
        if t < ti:
            t = ti
        if t > tf:
            t = tf
            
        tp1 = t - ti
        tp2 = tp1*tp1
        tp3 = tp2*tp1
        tp4 = tp3*tp1
        tp5 = tp4*tp1
        
        th = c[0] + c[1]*tp1 + c[2]*tp2 + c[3]*tp3 + c[4]*tp4 + c[5]*tp5
        dth = c[1] + 2*c[2]*tp1 + 3*c[3]*tp2 + 4*c[4]*tp3 + 5*c[5]*tp4
        #ddth = 2*c[2] + 6*c[3]*tp1 + 12*c[4]*tp2 + 20*c[5]*tp3

        rC = r_c*np.cos(th); rS = r_c*np.sin(th)
        p = p_c + np.array([rC, rS])
        dp = np.array([-rS*dth, rC*dth])
        #ddp = np.array([-rS*ddth - rC*dth*dth, rC*ddth - rS*dth*dth])
        
        r = dp + K @ (p - f)
        
        if option == 'all':
            return p, dp, r
        elif option == 'reference':
            return r