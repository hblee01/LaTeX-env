# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import os

import lpc_model, lpc_task, lpc_control
#import lpc_u_vector_plot

import json, codecs  # to save/load variables to/from a file

import itertools        # for multi-processing nested for loops
import multiprocessing  # for multi-processing nested for loops
from functools import partial

class LpcPlot:
    def __init__(self, prm, total_num_iteration,
                 model=lpc_model.LpcTwoLinkManipulator(),
                 task=lpc_task.LpcTask(),
                 control=lpc_control.LpcControl()):
        self.prm = prm
        self.model = model
        self.task = task
        self.control = control
                
        N = total_num_iteration
        self.time = np.zeros(N)
        self.q = np.zeros((N,2))
        self.dq = np.zeros((N,2))
        self.f1 = np.zeros((N,2))
        self.f2 = np.zeros((N,2))
        self.p = np.zeros((N,2))
        self.error = np.zeros((N,2))
        self.residual = np.zeros((N,2))
        
        self.mu = np.zeros((N,2))
        self.mu_input = np.zeros((N,2))
        self.cii = np.zeros((N,2))
        self.lambda_squared = np.zeros((N,2))
        
        self.iterations_bw_frames = round(self.prm.movie_speed
                                        /(self.prm.dt * self.prm.movie_fps))
        
        self.itr = -1
        self.update(prm.ti)

    #%%
    @staticmethod
    def quiver_calculate_u_circular_path(x, l, ti, tf, c, r_c, p_c, K, method, parameter):
        t = x[0]; q = x[1:3]
        f, J = lpc_model.LpcTwoLinkManipulator.forward_kinematics(l, q, np.zeros(2), 'ee')
        r = lpc_task.LpcTask.calculate_task_circular(ti, tf, t, c, r_c, p_c, f, K, 'reference')
        u = lpc_control.LpcControl.inverse_kinematics(J, r, method, parameter)
        return u        
    #%%
    @staticmethod
    def quiver_calculate_u_linear_path(x, l, ti, tf, c, initial_point, final_point, K, method, parameter):
        t = x[0]; q = x[1:3]
        f, J = lpc_model.LpcTwoLinkManipulator.forward_kinematics(l, q, np.zeros(2), 'ee')
        r = lpc_task.LpcTask.calculate_task_linear(ti, tf, t, c, initial_point, final_point, f, K, 'reference')
        u = lpc_control.LpcControl.inverse_kinematics(J, r, method, parameter)
        return u        
                
    #%%
    def update(self, t):
        self.itr += 1
        self.time[self.itr] = t
        self.q[self.itr,:] = self.model.q
        self.dq[self.itr,:] = self.model.dq
        self.f1[self.itr,:] = self.model.f1
        self.f2[self.itr,:] = self.model.f2
        self.p[self.itr,:] = self.task.p
        self.error[self.itr,:] = self.task.p - self.model.f2
        self.residual[self.itr,:] = self.task.r - self.model.J2 @ self.control.u
        
        if self.prm.control_method in {4,5}:
            self.lambda_squared[self.itr,:] = self.control.lambda_squared
            
        if self.prm.control_method == 5:
            self.mu[self.itr,:] = self.control.mu
            self.mu_input[self.itr,:] = self.control.mu_input
            self.cii[self.itr,:] = self.control.cii
            
    #%%                   
    def save(self):
        if (self.prm.save_path == None) | (self.prm.save_data == 0):
            return
            
        data = [self.time,
                self.q,
                self.dq,
                self.f1,
                self.f2,
                self.p,
                self.error,
                self.residual]
        
        data = [x.tolist() for x in data]
        json.dump(data, 
                  codecs.open(os.path.join(self.prm.save_path,'data.txt'), 'w', encoding='utf-8'), 
                  separators=(',', ':'), 
                  sort_keys=True, 
                  indent=4)
    #%%
    def load(self):
        if self.prm.save_path == None:
            return
        
        ret = codecs.open(os.path.join(self.prm.save_path,'data.txt'), 'r', encoding='utf-8').read()
        data = json.loads(ret)
        [time, q, dq, f1, f2, p, error, residual] = [np.array(x) for x in data]
        
        test_flag = 0
        if test_flag == 1:
            plt.close('all')
            
            fig1, axs1 = plt.subplots(2,2)
            axs1[0,0].plot(time, q)
            axs1[0,0].grid(True)
            axs1[1,0].plot(time, dq)
            axs1[1,0].grid(True)
            axs1[0,1].plot(time, error)
            axs1[0,1].grid(True)
            axs1[1,1].plot(time, residual)
            axs1[1,1].grid(True)
            
            fig2, axs2 = plt.subplots()
            axs2.plot(p[:,0], p[:,1])
            axs2.plot(f2[:,0], f2[:,1],marker='o', markevery=100)
            axs2.axis('equal')
            axs2.grid(True)
            
            plt.show()
        
    #%%
    def plot(self):
        #%%
        fig_num = 0
        fig_size = (2*self.prm.figure_size[0], self.prm.figure_size[1])
        fig, axs = plt.subplots(2,3,figsize=fig_size)
        
        axs[0,0].plot(self.q[:,0], self.q[:,1]) #, marker='o', markevery=100)
        axs[0,0].axis('equal')
        axs[0,0].grid()
        axs[0,0].set_title('joint trajectory')
        axs[0,0].set_xlabel(r'$q_1$ [rad]')
        axs[0,0].set_ylabel(r'$q_2$ [rad]')
        
        axs[1,0].plot(self.p[:,0], self.p[:,1]) #, marker='o', markevery=100)
        axs[1,0].plot(self.f2[:,0], self.f2[:,1]) #, marker='o', markevery=100)
        axs[1,0].axis('equal')
        axs[1,0].grid()
        axs[1,0].set_title('task trajectory')
        axs[1,0].set_xlabel(r'$x$ [m]')
        axs[1,0].set_ylabel(r'$y$ [m]')
        
        axs[0,1].plot(self.time, self.q)
        axs[0,1].grid()
        axs[0,1].set_title('joint angle')
        
        axs[1,1].plot(self.time, self.dq)
        axs[1,1].grid()
        axs[1,1].set_title('joint velocity')
        
        axs[0,2].plot(self.time, self.error)
        axs[0,2].grid()
        axs[0,2].set_title('task error')
        
        axs[1,2].plot(self.time, self.residual)
        axs[1,2].grid()
        axs[1,2].set_title('residual')
        
        fig.tight_layout()
        
        if (self.prm.save_path != None) & (self.prm.save_figure == 1):
            file_name = os.path.join(self.prm.save_path,f'simulation{fig_num}_basic_plots.{self.prm.figure_format}')
            plt.savefig(file_name, format=self.prm.figure_format)
        #%%
        if self.prm.make_movie == 1:
            fig_num += 1
            fig_size = (2*self.prm.figure_size[0], self.prm.figure_size[1])
            fig, axs = plt.subplots(ncols=3, nrows=3, figsize=fig_size)
            
            gs = axs[0,0].get_gridspec()
            for i in range(2):
                for j in range(2):
                    axs[i,j].remove()
            axs1 = fig.add_subplot(gs[0:2,0:2])
            axs2 = axs[2,0]
            axs3 = axs[2,1]
            
            gs = axs[0,2].get_gridspec()
            for i in range(3):
                axs[i,2].remove()
            axs4 = fig.add_subplot(gs[:,2])
            
            #%%
            axs1.autoscale(False)
            axs1.set_xlim(-0.2, 1.4)
            axs1.set_ylim(-0.6, 0.6)
            axs1.set_aspect('equal')
            axs1.grid()
            
            circle = plt.Circle((0,0), np.sum(self.model.l), linestyle=':', 
                                color='k', fill=False)
            axs1.add_artist(circle)
            
            manipulator, = axs1.plot([], [], 'o-', color='k', lw=2)
            trajectory_p, = axs1.plot([], [], '--', color='b', lw=1, 
                                        marker='.', markevery=100)
            trajectory_f, = axs1.plot([], [], '-', color='r', lw=1, 
                                        marker='.', markevery=100)
            time_template = 'time = %.3fs / speed = %g'
            time_text = axs1.text(0.05, 0.9, '', transform=axs1.transAxes, 
                                    color='k')
            
            fx = []; fy = []
            px = []; py = []
            #%%
            axs2.autoscale(False)
            axs2.set_xlim(self.prm.ti, self.prm.tf)
            q_min = np.min(self.q); q_max = np.max(self.q)
            q_offset = (q_max-q_min)*0.05
            axs2.set_ylim(q_min-q_offset, q_max+q_offset)
            axs2.grid()
            axs2.set_title('joint analge')
            
            axs3.autoscale(False)
            axs3.set_xlim(self.prm.ti, self.prm.tf)
            dq_min = np.min(self.dq); dq_max = np.max(self.dq)
            dq_offset = (dq_max-dq_min)*0.05
            axs3.set_ylim(dq_min-dq_offset, dq_max+dq_offset)
            axs3.grid()
            axs3.set_title('joint velocity')
            
            plot_q1, = axs2.plot([], [])
            plot_q2, = axs2.plot([], [])
            plot_dq1, = axs3.plot([], [])
            plot_dq2, = axs3.plot([], [])
            
            t = []; q1 = []; q2 = []; dq1 = []; dq2 = []
            #%%
            q1_num = 21
            q1_min = np.min(self.q[:,0])
            q1_max = np.max(self.q[:,0])
            q1_offset = (q1_max - q1_min) * 0.1
            q1_lim = np.array([q1_min-q1_offset, q1_max+q1_offset])
            quiver_q1 = np.linspace(q1_lim[0], q1_lim[1], q1_num)
            quiver_q1_degree = quiver_q1 * 180 / np.pi
            
            q2_num = 21
            q2_min = np.min(self.q[:,1])
            q2_max = np.max(self.q[:,1])
            q2_offset = (q2_max - q2_min) * 0.1
            q2_lim = np.array([q2_min-q2_offset, q2_max+q2_offset])
            quiver_q2 = np.linspace(q2_lim[0], q2_lim[1], q2_num)
            quiver_q2_degree = quiver_q2 * 180 / np.pi
            
            N = round(len(self.time) / self.iterations_bw_frames)
            quiver_t = [self.time[i*self.iterations_bw_frames] for i in range(N)]
            
            quiver_u1 = np.zeros((N, q1_num, q2_num))
            quiver_u2 = np.zeros((N, q1_num, q2_num))
            
            paramlist = list(itertools.product(quiver_t, quiver_q1, quiver_q2))
            pool = multiprocessing.Pool()
            
            if self.task.method == 0:
                res = pool.map(partial(LpcPlot.quiver_calculate_u_linear_path,
                                        l=self.model.l, 
                                        ti=self.task.ti, 
                                        tf=self.task.tf, 
                                        c=self.task.coefficient, 
                                        initial_point=self.task.initial_point, 
                                        final_point=self.task.final_point, 
                                        K=self.task.K, 
                                        method=self.control.method, 
                                        parameter=self.control.parameter), 
                                paramlist)
            elif self.task.method == 1:
                res = pool.map(partial(LpcPlot.quiver_calculate_u_circular_path,
                                        l=self.model.l, 
                                        ti=self.task.ti, 
                                        tf=self.task.tf, 
                                        c=self.task.coefficient, 
                                        r_c=self.task.radius, 
                                        p_c=self.task.center, 
                                        K=self.task.K, 
                                        method=self.control.method, 
                                        parameter=self.control.parameter), 
                                paramlist)
            
            num = 0
            for i in range(N):
                for j in range(q1_num):
                    for k in range(q2_num):
                        quiver_u1[i,j,k] = res[num][0]
                        quiver_u2[i,j,k] = res[num][1]
                        num += 1
            
            axs4.autoscale(False)
            axs4.set_xlim(q1_lim * 180 / np.pi)
            axs4.set_ylim(q2_lim * 180 / np.pi)
            axs4.set_aspect('equal')
            axs4.grid()
            
            quiver = axs4.quiver(quiver_q1_degree,
                                      quiver_q2_degree,
                                      quiver_u1[0,:,:].T, 
                                      quiver_u2[0,:,:].T)
            
            trajectory_q, = axs4.plot([], [], '-', color='r', lw=1,
                                          marker='.', markevery=100)
            
            q_degree = self.q * 180 / np.pi
            quiver_plot_q1 = []; quiver_plot_q2 = []
            #%%
            fig.tight_layout()
            #%%
            def animate(itr):
                ibf = self.iterations_bw_frames
                i = itr * ibf
                manipulator_x = [0, self.f1[i,0], self.f2[i,0]]
                manipulator_y = [0, self.f1[i,1], self.f2[i,1]]
                manipulator.set_data(manipulator_x, manipulator_y)
                
                quiver.set_UVC(quiver_u1[itr,:,:].T, 
                                quiver_u2[itr,:,:].T)
                
                I = list(range((itr-1)*ibf+1, itr*ibf+1))  
                # I = [(itr-1)*ibf+1, itr*ibf+1) 
                # => -ibf+1,-ibf+2,...,0 / 1,2,...,ibf / ibf+1,ibf_2,...,2*ibf / ...
                for i in I:
                    if i >= 0:
                        px.append(self.p[i,0])
                        py.append(self.p[i,1])
                        fx.append(self.f2[i,0])
                        fy.append(self.f2[i,1])
                        quiver_plot_q1.append(q_degree[i,0])
                        quiver_plot_q2.append(q_degree[i,1])
                        t.append(self.time[i])
                        q1.append(self.q[i,0])
                        q2.append(self.q[i,1])
                        dq1.append(self.dq[i,0])
                        dq2.append(self.dq[i,1])
                
                trajectory_p.set_data(px, py)
                trajectory_f.set_data(fx, fy)
                trajectory_q.set_data(quiver_plot_q1, quiver_plot_q2)
                plot_q1.set_data(t, q1)
                plot_q2.set_data(t, q2)
                plot_dq1.set_data(t, dq1)
                plot_dq2.set_data(t, dq2)
                
                time_text.set_text(time_template 
                                    % (self.prm.ti + i*self.prm.dt, 
                                      self.prm.movie_speed))
                
                return (manipulator, 
                        trajectory_p, 
                        trajectory_f,
                        time_text,
                        quiver,
                        trajectory_q,
                        plot_q1,
                        plot_q2,
                        plot_dq1,
                        plot_dq2)
            
            ani = animation.FuncAnimation(
                fig = fig,  # figure object
                func = animate,  # function to call at each frame
                frames = len(self.time) // self.iterations_bw_frames,
                            # if an integer, then equivalent to pass range(frames)
                interval = round(1000/self.prm.movie_fps),  
                            # delay between frames in milliseconds
                blit=True,  # 
                repeat=False)  # whether the animation repeats
            
            if (self.prm.save_path != None) & (self.prm.save_movie == 1):
                writer = animation.FFMpegWriter(
                    fps=self.prm.movie_fps,  # movie frame rate per second
                    bitrate=1800,  # bitrate of the movie, in kilobits per second
                    metadata=dict(artist='Sangik'))  # a dictionary of keys and 
                              # values for metadata to include in the output file    
                ani.save(os.path.join(self.prm.save_path,'simulation{fig_num}_movie.mp4'), writer=writer)
        #%%    
        plt.show()
