# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import os

import itertools        # for multi-processing nested for loops
import multiprocessing  # for multi-processing nested for loops
from functools import partial

import lpc_model, lpc_task, lpc_control

class LpcUVectorPlot():
    def __init__(self, prm, t, q1_lim, q2_lim, arrow_scale=None):
        self.prm = prm
        
        q1_num = 21
        q1_lim_degree = q1_lim * 180 / np.pi
        q1 = np.linspace(q1_lim[0], q1_lim[1], q1_num)
        q1_degree = q1 * 180 / np.pi
        
        q2_num = 21
        q2_lim_degree = q2_lim * 180 / np.pi
        q2 = np.linspace(q2_lim[0], q2_lim[1], q2_num)
        q2_degree = q2 * 180 / np.pi
        
        U = np.zeros((q1_num, q2_num))
        V = np.zeros((q1_num, q2_num))
        
        paramlist = list(itertools.product(q1, q2))
        pool = multiprocessing.Pool()
        
        model = lpc_model.LpcTwoLinkManipulator(prm.l1, prm.l2, 
                                                prm.q1, prm.q2,
                                                prm.dq1, prm.dq2)
        task = lpc_task.LpcTask(model, prm.ti_task, prm.tp_task, prm.clik)
        control = lpc_control.LpcControl(task, prm.method, prm.parameter)
        
        res  = pool.map(partial(LpcUVectorPlot.calculate_u, 
                                l=model.l,
                                ti=task.ti,
                                tf=task.tf,
                                t=t,
                                c=task.coefficient,
                                r_c=task.radius,
                                p_c=task.center,
                                K=task.K,
                                method=control.method,
                                parameter=control.parameter),
                        paramlist)
        
        num = 0
        for i in range(q1_num):
            for j in range(q2_num):
                U[i,j] = res[num][0]
                V[i,j] = res[num][1]
                num += 1
                
        # ---------------------------------------------------------------------
        fig, axs = plt.subplots(figsize=prm.figure_size)
        
        if arrow_scale == None:
            axs.quiver(q1_degree, q2_degree, U.T, V.T)
        else:
            axs.quiver(q1_degree, q2_degree, U.T, V.T,
                       angles='xy', scale_units='inches', scale=arrow_scale)
            
        axs.set_xticks(np.linspace(q1_lim_degree[0],q1_lim_degree[1],5))
        axs.set_yticks(np.linspace(q2_lim_degree[0],q2_lim_degree[1],5))
        axs.tick_params(axis='both', which='major', labelsize=18)
        axs.grid()
        axs.set_aspect('equal')
        fig.tight_layout()
        
        self.fig = fig; self.axs = axs
        
    def save(self, file_name):
        if self.prm.save_path != None:
            full_file_name = os.path.join(self.prm.save_path, f'{file_name}.{self.prm.figure_format}')
            self.fig.savefig(full_file_name, format=self.prm.figure_format)
        else:
            print('Failed to save the figure: self.prm.save_path = None')
        
    # A function which will process a tuple of parameters
    @staticmethod
    def calculate_u(q, l, ti, tf, t, c, r_c, p_c, K, method, parameter):
        f, J = lpc_model.LpcTwoLinkManipulator.forward_kinematics(l, q, np.zeros(2), 'ee')
        r = lpc_task.LpcTask.calculate_task(ti, tf, t, c, r_c, p_c, f, K, 'reference')
        u = lpc_control.LpcControl.inverse_kinematics(J, r, method, parameter)
        
        return u