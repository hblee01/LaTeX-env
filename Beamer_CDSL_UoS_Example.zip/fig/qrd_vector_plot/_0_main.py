# -*- coding: utf-8 -*-

#%% QRD Vector Plot

from lpc_parameter import LpcParameter as prm
from _1_qrd_vector_plot import QrdVectorPlot
QrdVectorPlot(prm("qrd_vector_plot"))

#%% Inverse Kinematics Circular Path

# from lpc_parameter import LpcParameter as prm
# from _2_inverse_kinematics_circular_path import InverseKinematicsCircularPath
# InverseKinematicsCircularPath(prm("inverse_kinematics_circular_path"))
# #InverseKinematicsCircularPath(prm())

#%% Inverse Kinematics Linear Path

# from lpc_parameter import LpcParameter as prm
# from _3_inverse_kinematics_linear_path import InverseKinematicsLinearPath
# #InverseKinematicsLinearPath(prm("inverse_kinematics_linear_path"))
# InverseKinematicsLinearPath(prm())

#%%

# from lpc_parameter import LpcParameter
# from lpc_simulation import LpcSimulation

# LpcSimulation(LpcParameter(dir_name=None, 
#                             task_method=1, task_parameter=[], 
#                             #control_method=0, control_parameter=[0.02]
#                             #control_method=2, control_parameter=[0.1,0.1]
#                             #control_method=3, control_parameter=[0.01,0.2,0.2]
#                             #control_method=4, control_parameter=[0.01,0.01,1]
#                             control_method=5, control_parameter=[0.001,0.001,0.01,0.01,100,1]
#                             ))