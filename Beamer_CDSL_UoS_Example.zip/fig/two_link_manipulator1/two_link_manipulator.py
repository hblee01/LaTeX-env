# -*- coding: utf-8 -*-

import os, sys, datetime, pathlib, shutil # to save figures
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

mpl.rcParams['backend'] = 'Qt5Agg' # or mpl.use('Qt5Agg')
mpl.rcParams['axes.grid'] = True
# mpl.rcParams['toolbar'] = 'None' # disable toolbar
mpl.rcParams['text.usetex'] = True

plt.close('all')

def main():
    test = 1
    save_figure = 1

    # parameters
    if test == 0:
        q0 = np.array([30, 60])*np.pi/180
    elif test == 1:
        q0 = np.array([30, 60])*np.pi/180
    elif test == 2:
        q0 = np.array([-30, 60])*np.pi/180
    L1 = 0.5
    L2 = 0.5
    scale = 1
    omega1 = 2*np.pi*10
    zeta1 = 1
    omega2 = 2*np.pi*10
    zeta2 = 1
    inverse_method = 0 # 0: constant damping, 1: varying damping
    lambda1 = 0.8
    lambda2 = 0.8
    # lambda1 = 0.5
    # lambda2 = 0.5
    # mu1 = 0.04
    # mu2 = 0.04
    mu1 = 0.04
    mu2 = 0.04
    epsilon = 0.000000001

    ti = 0
    tf = 10
    dt = 0.001
    tp = tf - ti
    N = round(tp/dt)
    tc = ti
    n = 0

    # figure parameters
    # title_fontsize = 22
    # label_fontsize = 20
    # tick_fontsize = 20
    # legend_fontsize = 18
    title_fontsize = 22
    label_fontsize = 25
    tick_fontsize = 25
    legend_fontsize = 22

    # data save
    date_time = datetime.datetime.now().strftime(f"%Y%m%d_%H%M%S_two_link_manipulator")
    save_path = os.path.join(os.getcwd(), "data", date_time)
    if os.path.exists(save_path) == True:
        print(f"save_path exists: save_path = {save_path}")
        sys.exit()
    else:
        pathlib.Path(save_path).mkdir(parents=True, exist_ok=True)
        src_path = os.getcwd()
        src_files = os.listdir(src_path)
        for file_name in src_files:
            full_file_name = os.path.join(src_path, file_name)
            if os.path.isfile(full_file_name) & (full_file_name[-3:] == '.py'):
                shutil.copy(full_file_name, save_path)

    # variables
    t = np.zeros(N)
    q = np.zeros((2,N))
    dq = np.zeros((2,N))
    ddq = np.zeros((2,N))
    y = np.zeros((2,N))
    dy = np.zeros((2,N))
    ddy = np.zeros((2,N))
    Lf2h = np.zeros((2,N))
    J = np.zeros((2,2,N))
    C = np.zeros((2,2,N))
    Jh = np.zeros((2,2,N))
    p = np.zeros((2,N))
    dp = np.zeros((2,N))
    ddp = np.zeros((2,N))
    e = np.zeros((2,N))
    de = np.zeros((2,N))
    dde = np.zeros((2,N))
    u = np.zeros((2,N))

    # initial values
    t[0] = ti
    q[:,0] = q0
    dq[:,0] = np.zeros(2)
    ddq[:,0] = np.zeros(2)
    u[:,0] = np.zeros(2)
    y[:,0], dy[:,0], ddy[:,0], Lf2h[:,0], J[:,:,0] = forward_kinematics(L1, L2, q[:,0], dq[:,0], u[:,0])
    Q, R = qr_mgs(J[:,:,0].T)
    C[:,:,0] = R.T
    Jh[:,:,0] = Q.T
    
    # trajectory generation
    p_i = y[:,0]
    p_c = scale * (L1 + L2) * p_i / np.linalg.norm(p_i)
    r = np.linalg.norm(p_c - p_i)
    p_ci = p_i - p_c
    th_i = np.arctan2(p_ci[1], p_ci[0])
    th_f = th_i + 2*np.pi
    dth_i = dth_f = 0.0
    ddth_i = ddth_f = 0.0
    
    tp1 = tp
    tp2 = tp1*tp1
    tp3 = tp2*tp1
    tp4 = tp3*tp1
    tp5 = tp4*tp1
    
    c0 = th_i
    c1 = dth_i
    c2 = ddth_i/2
    c3 = ( 20*(th_f-th_i) - (8*dth_f+12*dth_i)*tp1 - (3*ddth_i-ddth_f)*tp2 )/(2*tp3)
    c4 = ( 30*(th_i-th_f) + (14*dth_f+16*dth_i)*tp1 + (3*ddth_i-2*ddth_f)*tp2 )/(2*tp4)
    c5 = ( 12*(th_f-th_i) - (6*dth_f+6*dth_i)*tp1 - (ddth_i-ddth_f)*tp2 )/(2*tp5)

    radius = r
    center = p_c
    coefficient = np.array([c0, c1, c2, c3, c4, c5])

    # initial values of p, dp, ddp
    th = c0
    dth = c1
    ddth = 2*c2
    rC = r*np.cos(th); rS = r*np.sin(th)
    p[:,0] = p_c + np.array([rC, rS])
    dp[:,0] = np.array([-rS*dth, rC*dth])
    ddp[:,0] = np.array([-rS*ddth - rC*dth*dth, rC*ddth - rS*dth*dth])
    e[:,0] = p[:,0] - y[:,0]
    de[:,0] = dp[:,0] - dy[:,0]
    dde[:,0] = ddp[:,0] - ddy[:,0]

    # run simulation
    while n < N-1:
        n += 1
        tc += dt
        n = n
        tc = tc

        t[n] = tc
        p[:,n], dp[:,n], ddp[:,n] = desired_trajectory(radius, center, coefficient, ti, tf, tc)
        e[:,n] = p[:,n] - y[:,n-1]
        de[:,n] = dp[:,n] - dy[:,n-1]
        dde[:,n] = ddp[:,n] - ddy[:,n-1]
        ref1 = ddp[0,n] + 2*zeta1*omega1*de[0,n] + omega1**2*e[0,n] - Lf2h[0,n-1]
        ref2 = ddp[1,n] + 2*zeta2*omega2*de[1,n] + omega2**2*e[1,n] - Lf2h[1,n-1]
        ref = np.array([ref1, ref2])

        c11 = C[0,0,n-1]
        c21 = C[1,0,n-1]
        c22 = C[1,1,n-1]
        if inverse_method == 0:
            inv_c11 = c11/(c11**2+lambda1**2)
            inv_c22 = c22/(c22**2+lambda2**2)
            # inv_c11 = c11*np.linalg.pinv(np.array([[c11**2+lambda1**2]]))[0,0]
            # inv_c22 = c22*np.linalg.pinv(np.array([[c22**2+lambda2**2]]))[0,0]
        elif inverse_method == 1:
            # inv_c11 = c11/(c11**2 + mu1**2/(c11**2+epsilon**2))
            # inv_c22 = c22/(c22**2 + mu2**2/(c22**2+epsilon**2))
            inv_c11 = c11/(c11**2 + mu1**2/(c11**2+epsilon**2))
            inv_c22 = c22/(c22**2 + mu2**2/(c22**2+epsilon**2))
        invC = np.array([[inv_c11, 0], [-inv_c22*c21*inv_c11, inv_c22]])
        u[:,n] = Jh[:,:,n-1].T @ invC @ ref

        ddq[:,n] = u[:,n]
        dq[:,n] = dq[:,n-1] + ddq[:,n] * dt
        q[:,n] = q[:,n-1] + dq[:,n] * dt
        y[:,n], dy[:,n], ddy[:,n], Lf2h[:,n], J[:,:,n] = forward_kinematics(L1, L2, q[:,n], dq[:,n], u[:,n])
        Q, R = qr_mgs(J[:,:,n].T)
        C[:,:,n] = R.T
        Jh[:,:,n] = Q.T

    if test == 0:
        # plot results
        fig, axs = plt.subplots(2,3)
        axs[0,0].plot(t, q.T)
        axs[0,0].set_title(r'$q$')
        axs[0,1].plot(t, dq.T)
        axs[0,1].set_title(r'$\dot{q}$')
        axs[0,2].plot(t,u.T)
        axs[0,2].set_title(r'$u = \ddot{q}$')
        # axs[1,0].plot(t, p.T, t, y.T)
        # axs[1,0].set_title(r'$p$ and $y$')
        axs[1,0].plot(t, C[0,0,:], t, C[1,1,:])
        axs[1,0].set_title(r'$c_{11},\,c_{22}$')
        axs[1,1].plot(t, e.T)
        axs[1,1].set_title(r'$e$')
        axs[1,2].plot(p[0,:], p[1,:], y[0,:], y[1,:])
        axs[1,2].set_title(r'$(y_1,y_2)$')
        axs[1,2].set_aspect('equal')
        # axs[1,2].plot(q[0,:], q[1,:])
        # axs[1,2].set_title(r'$(q_1,q_2)$')
        # axs[1,2].plot(t, de.T)
        # axs[1,2].set_title(r'$\dot{e}$')
        for i in range(len(t)):
            if t[i] % 0.1 < dt:
                axs[1,2].plot([p[0,i], y[0,i]], [p[1,i], y[1,i]], 'k:')
    
    elif test == 1:
        
        # end-effector path
        fig, axs = plt.subplots()
        fig.set_size_inches(4,4)
        axs.plot(p[0,:], p[1,:], 'k--', label=r'$p(t)$')
        axs.plot(y[0,:], y[1,:], 'k', label=r'$y(t)$')
        circle = plt.Circle((0, 0), L1+L2, color='gray', alpha=0.2)
        axs.add_artist(circle)
        axs.set_aspect('equal')
        for i in range(len(t)):
            if t[i] % 0.1 < dt:
                axs.plot([p[0,i], y[0,i]], [p[1,i], y[1,i]], 'k:')
        axs.set_xlim(0.35,0.65)
        axs.set_xticks([0.4,0.5,0.6])
        axs.set_ylim(0.72, 1.02)
        # axs.set_yticks([0.75, 0.85, 0.95])
        axs.set_yticks([0.8, 0.9, 1.0])
        for tick in axs.xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs.yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs.legend(fontsize=legend_fontsize, framealpha=0.0, loc='lower left', bbox_to_anchor=(0.1,0.1))
        fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        if (save_path != None) & (save_figure == 1):
            file_name = os.path.join(save_path,f'path.pdf')
            fig.savefig(file_name, format='pdf')

        # all together
        fig, axs = plt.subplots(3,1,sharex=True)
        fig.set_size_inches(6,7.5)

        # error
        axs[0].plot(t, e[0,:], 'k', label=r'$e_1(t)$')
        axs[0].plot(t, e[1,:], 'k--', label=r'$e_2(t)$')
        axs[0].set_xlim(ti,tf)
        axs[0].set_xticks(np.linspace(ti,tf,6))
        axs[0].set_ylim(-0.02, 0.17)
        axs[0].set_yticks([0, 0.1])
        for tick in axs[0].xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs[0].yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs[0].legend(fontsize=legend_fontsize, framealpha=0.0, loc='upper right', bbox_to_anchor=(1.05,1.08))
        
        # joint angle
        axs[1].plot(t, q[0,:]*180/np.pi, 'k', label=r'$q_1(t)$')
        axs[1].plot(t, q[1,:]*180/np.pi, 'k--', label=r'$q_2(t)$')
        axs[1].set_xlim(ti,tf)
        axs[1].set_xticks(np.linspace(ti,tf,6))
        axs[1].set_ylim(-20, 80)
        axs[1].set_yticks([0, 40])
        for tick in axs[1].xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs[1].yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs[1].legend(fontsize=legend_fontsize, framealpha=0.0, loc='upper right', bbox_to_anchor=(1.05,0.55))
        
        # control input
        axs[2].plot(t, u[0,:], 'k', label=r'$u_1(t)$')
        axs[2].plot(t, u[1,:], 'k--', label=r'$u_2(t)$')
        axs[2].set_xlim(ti,tf)
        axs[2].set_xticks(np.linspace(ti,tf,6))
        axs[2].set_ylim(-45, 45)
        axs[2].set_yticks([-30, 0, 30])
        for tick in axs[2].xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs[2].yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs[2].legend(fontsize=legend_fontsize, framealpha=0.0, loc='upper right', bbox_to_anchor=(1.05,1.08))
        axs[2].set_xlabel(r'$\mathrm{time [s]}$', fontsize=label_fontsize)

        # save figure
        fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        if (save_path != None) & (save_figure == 1):
            file_name = os.path.join(save_path,f'error.pdf')
            fig.savefig(file_name, format='pdf')

    
    elif test == 2:
        # end-effector path
        fig, axs = plt.subplots()
        fig.set_size_inches(4,4)
        axs.plot(p[0,:], p[1,:], 'k--', label=r'$p(t)$')
        axs.plot(y[0,:], y[1,:], 'k', label=r'$y(t)$')
        circle = plt.Circle((0, 0), L1+L2, color='gray', alpha=0.2)
        axs.add_artist(circle)
        axs.set_aspect('equal')
        for i in range(len(t)):
            if t[i] % 0.1 < dt:
                axs.plot([p[0,i], y[0,i]], [p[1,i], y[1,i]], 'k:')
        axs.set_xlim(0.85,1.15)
        axs.set_xticks([0.9, 1.0, 1.1])
        axs.set_ylim(-0.15, 0.15)
        axs.set_yticks([-0.1, 0, 0.1])
        for tick in axs.xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs.yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs.legend(fontsize=legend_fontsize, framealpha=0.0, loc='lower left', bbox_to_anchor=(-0.01,0.3))
        fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        if (save_path != None) & (save_figure == 1):
            file_name = os.path.join(save_path,f'path.pdf')
            fig.savefig(file_name, format='pdf')

        # all together
        fig, axs = plt.subplots(3,1,sharex=True)
        fig.set_size_inches(6,7.5)

        # error
        axs[0].plot(t, e[0,:], 'k', label=r'$e_1(t)$')
        axs[0].plot(t, e[1,:], 'k--', label=r'$e_2(t)$')
        axs[0].set_xlim(ti,tf)
        axs[0].set_xticks(np.linspace(ti,tf,6))
        axs[0].set_ylim(-0.15,0.15)
        axs[0].set_yticks([-0.1, 0, 0.1])
        for tick in axs[0].xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs[0].yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs[0].legend(fontsize=legend_fontsize, framealpha=0.0, loc='upper right', bbox_to_anchor=(1.05,1.08))
        
        # joint angle
        axs[1].plot(t, q[0,:]*180/np.pi, 'k', label=r'$q_1(t)$')
        axs[1].plot(t, q[1,:]*180/np.pi, 'k--', label=r'$q_2(t)$')
        axs[1].set_xlim(ti,tf)
        axs[1].set_xticks(np.linspace(ti,tf,6))
        axs[1].set_ylim(-40, 65)
        axs[1].set_yticks([-30, 0, 30, 60])
        for tick in axs[1].xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs[1].yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs[1].legend(fontsize=legend_fontsize, framealpha=0.0, loc='upper right', bbox_to_anchor=(1.05,0.8))
        
        # control input
        axs[2].plot(t, u[0,:], 'k', label=r'$u_1(t)$')
        axs[2].plot(t, u[1,:], 'k--', label=r'$u_2(t)$')
        axs[2].set_xlim(ti,tf)
        axs[2].set_xticks(np.linspace(ti,tf,6))
        axs[2].set_ylim(-220, 150)
        axs[2].set_yticks([-200, -100, 0, 100])
        for tick in axs[2].xaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        for tick in axs[2].yaxis.get_major_ticks():
            tick.label.set_fontsize(tick_fontsize)
        axs[2].legend(fontsize=legend_fontsize, framealpha=0.0, loc='upper right', bbox_to_anchor=(1.05,0.55))
        axs[2].set_xlabel(r'$\mathrm{time [s]}$', fontsize=label_fontsize)

        # save figure
        fig.tight_layout(pad=0, w_pad=0, h_pad=0)
        if (save_path != None) & (save_figure == 1):
            file_name = os.path.join(save_path,f'error.pdf')
            fig.savefig(file_name, format='pdf')

    plt.show()

def forward_kinematics(L1,L2,q,dq,u):
    q1 = q[0]; q2 = q[1]; q12 = q1 + q2
    C1 = np.cos(q1); C12 = np.cos(q12)
    S1 = np.sin(q1); S12 = np.sin(q12)
    L2C12 = L2*C12
    L1C1pL2C12 = L1*C1 + L2C12
    L2S12 = L2*S12
    L1S1pL2S12 = L1*S1 + L2S12
    J = np.array([ [-L1S1pL2S12, -L2S12], [L1C1pL2C12, L2C12] ])
    H1 = np.array([ [-L1C1pL2C12, -L2C12], [-L2C12, -L2C12] ])
    H2 = np.array([ [-L1S1pL2S12, -L2S12], [-L2S12, -L2S12] ])

    y = np.array([L1C1pL2C12, L1S1pL2S12])
    dy = J @ dq
    Lf2h = np.array([dq.T @ H1 @ dq, dq.T @ H2 @ dq])
    ddy = Lf2h + J @ u

    return y, dy, ddy, Lf2h, J

def desired_trajectory(r, p_c, c, ti, tf, tc):
    if tc < ti:
        tc = ti
    if tc > tf:
        tc = tf
        
    tp1 = tc - ti
    tp2 = tp1*tp1
    tp3 = tp2*tp1
    tp4 = tp3*tp1
    tp5 = tp4*tp1

    th = c[0] + c[1]*tp1 + c[2]*tp2 + c[3]*tp3 + c[4]*tp4 + c[5]*tp5
    dth = c[1] + 2*c[2]*tp1 + 3*c[3]*tp2 + 4*c[4]*tp3 + 5*c[5]*tp4
    ddth = 2*c[2] + 6*c[3]*tp1 + 12*c[4]*tp2 + 20*c[5]*tp3

    rC = r*np.cos(th); rS = r*np.sin(th)
    p = p_c + np.array([rC, rS])
    dp = np.array([-rS*dth, rC*dth])
    ddp = np.array([-rS*ddth - rC*dth*dth, rC*ddth - rS*dth*dth])

    return p, dp, ddp

def qr_mgs(A):
    """
    - QR decomposition algorithm using the modified Gram-Schmit 
        orthogonalization based on Trefethen and Bau, Algorithm 8.1.
    - It provides only the reduced QR decompositions according to the dimension 
        of A.
    - The algorithm is modified to increase the numerical stability
    """
    m, n = A.shape
    epsilon = 0.000000001  # tolerance for the inverse

    if n > m:
        print('qrd_mgs requires m >= n!')
        sys.exit()

    Q = A.copy()
    R = np.zeros((n,n))

    for i in range(n):
        R[i,i] = np.linalg.norm(Q[:,i])
        
        if R[i,i] < epsilon:
            Q[:,i] = np.zeros(m)
        else:
            Q[:,i] = Q[:,i] / R[i,i]
        
        for j in range(i+1, n):
            R[i,j] = Q[:,i].T @ Q[:,j]
            Q[:,j] = Q[:,j]- R[i,j] * Q[:,i]
            
            # if (i,j) == (2,3):
            #     print('R[i,i] = ', R[i,i])
            #     print('Q[:,i] = ', Q[:,i])
            #     print('Q[:,j] = ', Q[:,j])
            
    return Q, R
    
if __name__=='__main__':
    main()